# Auth, Registration, House Allocation, Email OTP, and Locked Access Changes

## Registration/login
- Landing/login screen now presents Login and Registration options.
- Resident registration collects Name, Email, Password, and Confirm Password.
- Society is fixed/hardcoded as **Uninav Heights**.
- Registration sends a 6-digit OTP to the resident email address.
- The resident account is created only after OTP verification succeeds.
- Registered residents log in with email and password.
- Unverified resident accounts cannot log in until email OTP verification is completed.

## House allocation
- After OTP verification, the app checks the seeded resident user list for an exact normalized name match.
- If exactly one seeded resident record matches, that same record is updated with the verified email/password, preserving its tower and house number.
- If no unique name match is found, the resident is created without tower/house and is sent to Profile.
- Unmatched residents now select their tower and house number from a Profile dropdown populated from available seeded house records.

## Locked resident access
- Residents without a configured tower and house number are redirected to Profile.
- Sidebar options are greyed out/disabled until the house request is approved and applied.
- Direct access to other resident modules is blocked while the account has no tower/house configured.
- Admin users and already configured residents are not affected.

## Profile/admin approval
- Residents can request a house/tower change from Profile.
- Requested house changes remain pending until an admin approves or rejects them.
- Admins can review pending requests from Settings → House Requests.
- Approved requests apply tower and house number immediately and unlock portal options.

## Database
- Added/ensured `society` on `users`.
- Added/ensured `otp_codes` for registration/reset/change-email OTPs.
- Added/ensured `user_house_change_requests` for admin approvals.
- Migration file: `sql/2026_04_auth_house_change.sql`.

## Additional update - Profile house request input
- House Number Change now supports both options:
  - select an available tower/house from the dropdown, or
  - enter Tower and House Number separately for admin review.
- Manual tower/house entries are normalized before submitting for admin approval.

## Additional update - Family member email OTP login
- Family member creation now requires an email address.
- Adding a family member creates a pending family account and sends a 6-digit OTP to that email.
- Family members must verify the OTP and set their own password before they can login.
- OTP verification and password setup now happen inline from the Family Members option.
- Family members login with email and password after activation.
- Primary residents can resend OTP for pending family members.
- Family member list now shows email and activation status.
- OTP purpose `family_register` was added to `otp_codes`.

## Additional update - Inline family member OTP verification
- Family member OTP verification and password setup are now done inside the Family Members option.
- The separate "Activate Family Login" link has been removed from the main login screen.
- Pending family members show an inline Verification Code, Set Password, and Confirm Password form.
- Family members still login only from the main login screen after activation.
- The old `auth/family_setup.php` page now redirects back to the main login screen with instructions.
