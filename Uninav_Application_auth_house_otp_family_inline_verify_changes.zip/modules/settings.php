<?php
require_once __DIR__ . '/../includes/layout.php';
require_admin();
$U = current_user();
$err = $msg = '';
ensure_auth_schema();

// Upgrade-safe Society SPOCs table for existing installations.
db()->exec("CREATE TABLE IF NOT EXISTS society_spocs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    department ENUM('Maintainance','Security','Gym','Park and Horticulture','House Keeping','Fire','Electricity','Water') NOT NULL,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NULL,
    phone VARCHAR(30) NULL,
    photo VARCHAR(255) NULL,
    notes VARCHAR(250) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (department)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Upgrade-safe Finance Incomes table for existing installations.
db()->exec("CREATE TABLE IF NOT EXISTS finance_incomes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    month_year VARCHAR(7) NOT NULL,
    income_date DATE NOT NULL,
    description VARCHAR(250) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (month_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

if ($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()) {
    $a = $_POST['action'] ?? '';

    // --- Events ---
    if ($a === 'event_add') {
        $img = upload_file($_FILES['image'] ?? [], 'events');
        db()->prepare('INSERT INTO events (title,description,event_date,event_time,location,image,created_by) VALUES (?,?,?,?,?,?,?)')
            ->execute([$_POST['title'],$_POST['description'],$_POST['event_date'],$_POST['event_time'] ?: null,$_POST['location'],$img,$U['id']]);
        $msg='Event added.';
    }
    if ($a === 'event_del') {
        db()->prepare('DELETE FROM events WHERE id=?')->execute([(int)$_POST['id']]);
        $msg='Event deleted.';
    }
    if ($a === 'event_update') {
        $id = (int)$_POST['id'];
        $img = upload_file($_FILES['image'] ?? [], 'events');
        if ($img) db()->prepare('UPDATE events SET title=?,description=?,event_date=?,event_time=?,location=?,image=? WHERE id=?')
                       ->execute([$_POST['title'],$_POST['description'],$_POST['event_date'],$_POST['event_time'] ?: null,$_POST['location'],$img,$id]);
        else db()->prepare('UPDATE events SET title=?,description=?,event_date=?,event_time=?,location=? WHERE id=?')
                 ->execute([$_POST['title'],$_POST['description'],$_POST['event_date'],$_POST['event_time'] ?: null,$_POST['location'],$id]);
        $msg='Event updated.';
    }

    // --- Notices ---
    if ($a === 'notice_add') {
        $img = upload_file($_FILES['image'] ?? [], 'notices');
        db()->prepare('INSERT INTO notices (title,body,image,posted_on,created_by) VALUES (?,?,?,?,?)')
            ->execute([$_POST['title'],$_POST['body'],$img, $_POST['posted_on'] ?: date('Y-m-d'), $U['id']]);
        $msg='Notice added.';
    }
    if ($a === 'notice_del') {
        db()->prepare('DELETE FROM notices WHERE id=?')->execute([(int)$_POST['id']]);
        $msg='Notice deleted.';
    }
    if ($a === 'notice_update') {
        $id = (int)$_POST['id'];
        $img = upload_file($_FILES['image'] ?? [], 'notices');
        if ($img) db()->prepare('UPDATE notices SET title=?,body=?,posted_on=?,image=? WHERE id=?')
                       ->execute([$_POST['title'],$_POST['body'],$_POST['posted_on'],$img,$id]);
        else db()->prepare('UPDATE notices SET title=?,body=?,posted_on=? WHERE id=?')
                 ->execute([$_POST['title'],$_POST['body'],$_POST['posted_on'],$id]);
        $msg='Notice updated.';
    }

    // --- Finance ---
    if ($a === 'finance_month_save') {
        $m  = $_POST['month_year'];
        $ob = (float)$_POST['opening_balance'];
        $ex = db()->prepare('SELECT id FROM finance_months WHERE month_year=?');
        $ex->execute([$m]);
        if ($ex->fetchColumn()) db()->prepare('UPDATE finance_months SET opening_balance=? WHERE month_year=?')->execute([$ob,$m]);
        else db()->prepare('INSERT INTO finance_months (month_year,opening_balance,monthly_income) VALUES (?,?,0)')->execute([$m,$ob]);
        $msg='Finance month saved.';
    }
    if ($a === 'finance_entry_add') {
        $entryDate = $_POST['entry_date'];
        $desc = trim($_POST['description'] ?? '');
        $expenseAmount = (float)($_POST['expense_amount'] ?? 0);
        $incomeAmount = (float)($_POST['income_amount'] ?? 0);
        $monthYear = substr($entryDate,0,7);
        if ($desc !== '' && $expenseAmount > 0) {
            db()->prepare('INSERT INTO finance_expenses (month_year,expense_date,description,amount) VALUES (?,?,?,?)')
                ->execute([$monthYear,$entryDate,$desc,$expenseAmount]);
        }
        if ($desc !== '' && $incomeAmount > 0) {
            db()->prepare('INSERT INTO finance_incomes (month_year,income_date,description,amount) VALUES (?,?,?,?)')
                ->execute([$monthYear,$entryDate,$desc,$incomeAmount]);
        }
        $msg = ($expenseAmount > 0 || $incomeAmount > 0) ? 'Finance entry added.' : 'Enter an income or expense amount.';
    }
    if ($a === 'finance_entry_del') {
        $id = (int)$_POST['id'];
        if (($_POST['entry_type'] ?? '') === 'income') {
            db()->prepare('DELETE FROM finance_incomes WHERE id=?')->execute([$id]);
            $msg='Income entry deleted.';
        } else {
            db()->prepare('DELETE FROM finance_expenses WHERE id=?')->execute([$id]);
            $msg='Expense entry deleted.';
        }
    }
    if ($a === 'finance_income_add') {
        db()->prepare('INSERT INTO finance_incomes (month_year,income_date,description,amount) VALUES (?,?,?,?)')
            ->execute([substr($_POST['income_date'],0,7),$_POST['income_date'],$_POST['description'],(float)$_POST['amount']]);
        $msg='Income added.';
    }
    if ($a === 'finance_income_del') {
        db()->prepare('DELETE FROM finance_incomes WHERE id=?')->execute([(int)$_POST['id']]);
        $msg='Income deleted.';
    }
    if ($a === 'finance_expense_add') {
        db()->prepare('INSERT INTO finance_expenses (month_year,expense_date,description,amount) VALUES (?,?,?,?)')
            ->execute([substr($_POST['expense_date'],0,7),$_POST['expense_date'],$_POST['description'],(float)$_POST['amount']]);
        $msg='Expense added.';
    }
    if ($a === 'finance_expense_del') {
        db()->prepare('DELETE FROM finance_expenses WHERE id=?')->execute([(int)$_POST['id']]);
        $msg='Expense deleted.';
    }

    // --- Vendors ---
    if ($a === 'vendor_add' || $a === 'vendor_update') {
        $photoRel = null;
        $up = upload_file($_FILES['photo'] ?? [], 'vendors'); if ($up) $photoRel = $up;
        if ($a === 'vendor_add') {
            db()->prepare('INSERT INTO vendors (category,name,photo,police_verified,contact_number,status,notes) VALUES (?,?,?,?,?,?,?)')
                ->execute([$_POST['category'],$_POST['name'],$photoRel, !empty($_POST['police_verified'])?1:0, $_POST['contact_number'], $_POST['status'], $_POST['notes']]);
            $vid = db()->lastInsertId();
        } else {
            $vid = (int)$_POST['id'];
            if ($photoRel) db()->prepare('UPDATE vendors SET category=?,name=?,photo=?,police_verified=?,contact_number=?,status=?,notes=? WHERE id=?')
                ->execute([$_POST['category'],$_POST['name'],$photoRel, !empty($_POST['police_verified'])?1:0, $_POST['contact_number'], $_POST['status'], $_POST['notes'], $vid]);
            else db()->prepare('UPDATE vendors SET category=?,name=?,police_verified=?,contact_number=?,status=?,notes=? WHERE id=?')
                ->execute([$_POST['category'],$_POST['name'], !empty($_POST['police_verified'])?1:0, $_POST['contact_number'], $_POST['status'], $_POST['notes'], $vid]);
        }
        // Refresh houses
        db()->prepare('DELETE FROM vendor_houses WHERE vendor_id=?')->execute([$vid]);
        $houses = explode(',', $_POST['houses'] ?? '');
        $ins = db()->prepare('INSERT INTO vendor_houses (vendor_id,tower,house_number) VALUES (?,?,?)');
        foreach ($houses as $h) {
            $h = trim($h);
            if ($h === '') continue;
            if (preg_match('/^([A-Ga-g])\s*-\s*(.+)$/', $h, $m2)) $ins->execute([$vid, strtoupper($m2[1]), trim($m2[2])]);
        }
        $msg='Vendor saved.';
    }
    if ($a === 'vendor_del') {
        $vid = (int)$_POST['id'];
        db()->prepare('DELETE FROM vendor_houses WHERE vendor_id=?')->execute([$vid]);
        db()->prepare('DELETE FROM vendors WHERE id=?')->execute([$vid]);
        $msg='Vendor removed.';
    }

    // --- Society SPOCs ---
    if ($a === 'spoc_add' || $a === 'spoc_update') {
        $photoRel = null;
        $up = upload_file($_FILES['photo'] ?? [], 'spocs'); if ($up) $photoRel = $up;
        if ($a === 'spoc_add') {
            db()->prepare('INSERT INTO society_spocs (department,name,email,phone,photo,notes) VALUES (?,?,?,?,?,?)')
                ->execute([$_POST['department'], $_POST['name'], $_POST['email'], $_POST['phone'], $photoRel, $_POST['notes']]);
            $msg='Society SPOC saved.';
        } else {
            $sid = (int)$_POST['id'];
            if ($photoRel) db()->prepare('UPDATE society_spocs SET department=?,name=?,email=?,phone=?,photo=?,notes=? WHERE id=?')
                ->execute([$_POST['department'], $_POST['name'], $_POST['email'], $_POST['phone'], $photoRel, $_POST['notes'], $sid]);
            else db()->prepare('UPDATE society_spocs SET department=?,name=?,email=?,phone=?,notes=? WHERE id=?')
                ->execute([$_POST['department'], $_POST['name'], $_POST['email'], $_POST['phone'], $_POST['notes'], $sid]);
            $msg='Society SPOC updated.';
        }
    }
    if ($a === 'spoc_del') {
        db()->prepare('DELETE FROM society_spocs WHERE id=?')->execute([(int)$_POST['id']]);
        $msg='Society SPOC removed.';
    }

    // --- Ads ---
    if ($a === 'ad_delete')    { db()->prepare('DELETE FROM advertisements WHERE id=?')->execute([(int)$_POST['id']]); $msg='Ad deleted.'; }
    if ($a === 'user_restrict'){ db()->prepare('UPDATE users SET ad_restricted=? WHERE id=?')->execute([(int)$_POST['restrict'],(int)$_POST['uid']]); $msg='Updated.'; }

    // --- Resident password reset approval ---
    if ($a === 'password_reset') {
        db()->prepare("UPDATE users SET password_hash=NULL, reset_requested=0, email_verified=0 WHERE id=? AND role='resident'")
            ->execute([(int)$_POST['uid']]);
        $msg='Password reset approved. Resident can register again from the login screen.';
    }

    // --- Resident house number change approval ---
    if ($a === 'house_request_decide') {
        $requestId = (int)($_POST['request_id'] ?? 0);
        $decision = $_POST['decision'] ?? '';
        $adminNote = trim($_POST['admin_note'] ?? '');
        $stmt = db()->prepare("SELECT r.*, u.owner_name, u.email FROM user_house_change_requests r JOIN users u ON u.id=r.user_id WHERE r.id=? AND r.status='pending' LIMIT 1");
        $stmt->execute([$requestId]);
        $req = $stmt->fetch();

        if (!$req) {
            $err = 'House change request not found or already decided.';
        } elseif ($decision === 'reject') {
            db()->prepare("UPDATE user_house_change_requests SET status='rejected', admin_id=?, admin_note=?, decided_at=NOW() WHERE id=?")
                ->execute([$U['id'], $adminNote, $requestId]);
            $msg = 'House number change request rejected.';
        } elseif ($decision === 'approve') {
            $tower = normalize_tower($req['requested_tower']);
            $house = normalize_house_number($req['requested_house_number']);
            $targetStmt = db()->prepare("SELECT * FROM users WHERE role='resident' AND tower=? AND house_number=? AND id<>? LIMIT 1");
            $targetStmt->execute([$tower, $house, (int)$req['user_id']]);
            $target = $targetStmt->fetch();

            if ($target && (!empty($target['password_hash']) || !empty($target['email']))) {
                $err = 'Cannot approve. The requested house is already assigned to a registered account.';
            } else {
                if ($target) {
                    db()->prepare("DELETE FROM users WHERE id=? AND role='resident'")->execute([(int)$target['id']]);
                }
                $username = resident_username($tower, $house);
                $check = db()->prepare('SELECT id FROM users WHERE username=? AND id<>? LIMIT 1');
                $check->execute([$username, (int)$req['user_id']]);
                if ($check->fetchColumn()) $username = unique_username($username);

                db()->prepare("UPDATE users SET tower=?, house_number=?, parent_user_id=NULL, username=?, society=? WHERE id=? AND role='resident'")
                    ->execute([$tower, $house, $username, default_society_name(), (int)$req['user_id']]);
                db()->prepare("UPDATE user_house_change_requests SET status='approved', admin_id=?, admin_note=?, decided_at=NOW() WHERE id=?")
                    ->execute([$U['id'], $adminNote, $requestId]);
                $msg = 'House number change approved and applied.';
            }
        } else {
            $err = 'Invalid house change decision.';
        }
    }
}

// Loads
$events   = db()->query('SELECT * FROM events ORDER BY event_date DESC LIMIT 200')->fetchAll();
$notices  = db()->query('SELECT * FROM notices ORDER BY posted_on DESC LIMIT 200')->fetchAll();
$months   = db()->query('SELECT * FROM finance_months ORDER BY month_year DESC LIMIT 24')->fetchAll();
$selMonth = $_GET['fm'] ?? date('Y-m');
$selMonthStmt = db()->prepare('SELECT * FROM finance_months WHERE month_year=?'); $selMonthStmt->execute([$selMonth]); $selMonthRow=$selMonthStmt->fetch();
$curIncs  = db()->prepare('SELECT * FROM finance_incomes WHERE month_year=? ORDER BY income_date DESC, id DESC'); $curIncs->execute([$selMonth]); $curIncs=$curIncs->fetchAll();
$curExps  = db()->prepare('SELECT * FROM finance_expenses WHERE month_year=? ORDER BY expense_date DESC, id DESC'); $curExps->execute([$selMonth]); $curExps=$curExps->fetchAll();
$financeRows = [];
foreach ($curIncs as $x) { $financeRows[] = ['type'=>'income','id'=>$x['id'],'date'=>$x['income_date'],'description'=>$x['description'],'income'=>(float)$x['amount'],'expense'=>0]; }
foreach ($curExps as $x) { $financeRows[] = ['type'=>'expense','id'=>$x['id'],'date'=>$x['expense_date'],'description'=>$x['description'],'income'=>0,'expense'=>(float)$x['amount']]; }
usort($financeRows, function($a,$b){ return strcmp($b['date'].'-'.$b['id'], $a['date'].'-'.$a['id']); });
$vendors  = db()->query('SELECT * FROM vendors ORDER BY category, name')->fetchAll();
$spocs    = db()->query("SELECT * FROM society_spocs ORDER BY FIELD(department, 'Maintainance','Security','Gym','Park and Horticulture','House Keeping','Fire','Electricity','Water'), name")->fetchAll();
$spocDepartments = ['Maintainance','Security','Gym','Park and Horticulture','House Keeping','Fire','Electricity','Water'];
$vhMap    = [];
foreach (db()->query('SELECT vendor_id,tower,house_number FROM vendor_houses')->fetchAll() as $r) {
    $vhMap[$r['vendor_id']][] = $r['tower'].'-'.$r['house_number'];
}
$ads     = db()->query('SELECT a.*, u.owner_name FROM advertisements a JOIN users u ON u.id=a.user_id ORDER BY a.id DESC')->fetchAll();
$houseRequests = db()->query("SELECT r.*, u.owner_name, u.email, u.username, u.tower AS user_tower, u.house_number AS user_house_number FROM user_house_change_requests r JOIN users u ON u.id=r.user_id ORDER BY FIELD(r.status, 'pending','approved','rejected'), r.id DESC LIMIT 200")->fetchAll();
$users   = db()->query("SELECT u.*, p.tower AS parent_tower, p.house_number AS parent_house_number FROM users u LEFT JOIN users p ON p.id=u.parent_user_id WHERE u.role='resident' ORDER BY reset_requested DESC, COALESCE(NULLIF(u.tower,''), p.tower), CAST(COALESCE(NULLIF(u.house_number,''), p.house_number) AS UNSIGNED), COALESCE(NULLIF(u.house_number,''), p.house_number), u.owner_name")->fetchAll();

layout_shell_start('Admin Settings','settings');
?>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
<?php if ($msg): ?><div class="alert ok"><?= e($msg) ?></div><?php endif; ?>

<div class="tabs">
  <a href="#events"   class="active" onclick="switchTab(this,'events')">Events</a>
  <a href="#notices"  onclick="switchTab(this,'notices')">Notices</a>
  <a href="#finance"  onclick="switchTab(this,'finance')">Finance</a>
  <a href="#vendors"  onclick="switchTab(this,'vendors')">3rd-Party Vendors</a>
  <a href="#spocs"    onclick="switchTab(this,'spocs')">Society SPOCs</a>
  <a href="#ads"      onclick="switchTab(this,'ads')">Ads</a>
  <a href="#house-requests" onclick="switchTab(this,'house-requests')">House Requests</a>
  <a href="#users"    onclick="switchTab(this,'users')">Users</a>
</div>

<!-- EVENTS -->
<section id="tab-events" class="tab-pane active">
  <h3>Add Event</h3>
  <form method="post" enctype="multipart/form-data" class="form">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <input type="hidden" name="action" value="event_add">
    <div class="grid2">
      <div><label>Title</label><input name="title" required></div>
      <div><label>Date</label><input type="date" name="event_date" required></div>
      <div><label>Time</label><input type="time" name="event_time"></div>
      <div><label>Location</label><input name="location"></div>
    </div>
    <label>Description</label><textarea name="description" rows="2"></textarea>
    <label>Image</label><input type="file" name="image" accept="image/*">
    <button class="btn primary">Add Event</button>
  </form>

  <h3>All Events</h3>
  <table class="tbl">
    <thead><tr><th>Date</th><th>Title</th><th>Location</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($events as $e): ?>
    <tr>
      <td><?= e(date('d M Y', strtotime($e['event_date']))) ?><?= $e['event_time']?' '.e(substr($e['event_time'],0,5)):'' ?></td>
      <td><?= e($e['title']) ?></td><td class="muted small"><?= e($e['location']) ?></td>
      <td>
        <details><summary><i class="fa fa-pen"></i> Edit</summary>
          <form method="post" enctype="multipart/form-data" class="form">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="event_update">
            <input type="hidden" name="id" value="<?= $e['id'] ?>">
            <label>Title</label><input name="title" value="<?= e($e['title']) ?>">
            <label>Date</label><input type="date" name="event_date" value="<?= e($e['event_date']) ?>">
            <label>Time</label><input type="time" name="event_time" value="<?= e($e['event_time']) ?>">
            <label>Location</label><input name="location" value="<?= e($e['location']) ?>">
            <label>Description</label><textarea name="description"><?= e($e['description']) ?></textarea>
            <label>Replace image</label><input type="file" name="image" accept="image/*">
            <button class="btn primary">Save</button>
          </form>
        </details>
        <form method="post" style="display:inline" onsubmit="return confirm('Delete event?')">
          <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
          <input type="hidden" name="action" value="event_del">
          <input type="hidden" name="id" value="<?= $e['id'] ?>">
          <button class="btn ghost"><i class="fa fa-trash"></i></button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<!-- NOTICES -->
<section id="tab-notices" class="tab-pane">
  <h3>Add Notice</h3>
  <form method="post" enctype="multipart/form-data" class="form">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <input type="hidden" name="action" value="notice_add">
    <div class="grid2">
      <div><label>Title</label><input name="title" required></div>
      <div><label>Posted On</label><input type="date" name="posted_on" value="<?= date('Y-m-d') ?>" required></div>
    </div>
    <label>Body</label><textarea name="body" rows="4" required></textarea>
    <label>Image</label><input type="file" name="image" accept="image/*">
    <button class="btn primary">Publish Notice</button>
  </form>

  <h3>All Notices</h3>
  <?php foreach ($notices as $n): ?>
    <div class="panel">
      <b><?= e($n['title']) ?></b> <span class="muted small">· <?= e(date('d M Y', strtotime($n['posted_on']))) ?></span>
      <details><summary>Edit</summary>
        <form method="post" enctype="multipart/form-data" class="form">
          <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
          <input type="hidden" name="action" value="notice_update">
          <input type="hidden" name="id" value="<?= $n['id'] ?>">
          <label>Title</label><input name="title" value="<?= e($n['title']) ?>">
          <label>Date</label><input type="date" name="posted_on" value="<?= e($n['posted_on']) ?>">
          <label>Body</label><textarea name="body" rows="3"><?= e($n['body']) ?></textarea>
          <label>Replace image</label><input type="file" name="image" accept="image/*">
          <button class="btn primary">Save</button>
        </form>
      </details>
      <form method="post" onsubmit="return confirm('Delete?')">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="notice_del">
        <input type="hidden" name="id" value="<?= $n['id'] ?>">
        <button class="btn ghost"><i class="fa fa-trash"></i> Delete</button>
      </form>
    </div>
  <?php endforeach; ?>
</section>

<!-- FINANCE -->
<section id="tab-finance" class="tab-pane">
  <h3>Monthly Setup</h3>
  <form method="post" class="form">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <input type="hidden" name="action" value="finance_month_save">
    <div class="grid2">
      <div><label>Month</label><input type="month" name="month_year" value="<?= e($selMonth) ?>" required></div>
      <div><label>Opening Balance</label><input type="number" step="0.01" name="opening_balance" value="<?= e($selMonthRow['opening_balance'] ?? '0') ?>"></div>
    </div>
    <p class="muted small">Monthly Income is now calculated from the income entries added below.</p>
    <button class="btn primary">Save Month</button>
  </form>

  <h3>Income & Expenses (<?= e($selMonth) ?>)</h3>
  <form method="get" class="filterbar"><input type="month" name="fm" value="<?= e($selMonth) ?>"><button class="btn primary">Load</button></form>
  <form method="post" class="form finance-entry-form">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <input type="hidden" name="action" value="finance_entry_add">
    <div class="grid4">
      <div><label>Date</label><input type="date" name="entry_date" required value="<?= e($selMonth.'-01') ?>"></div>
      <div><label>Description</label><input name="description" placeholder="Maintenance, electricity, interest, repair, etc." required></div>
      <div><label>Expense Amount</label><input type="number" step="0.01" min="0" name="expense_amount" placeholder="0.00"></div>
      <div><label>Income Amount</label><input type="number" step="0.01" min="0" name="income_amount" placeholder="0.00"></div>
    </div>
    <button class="btn primary">Add Finance Entry</button>
    <p class="muted small">Use one row and one button. Fill Expense, Income, or both if a transaction has both values.</p>
  </form>
  <table class="tbl">
    <thead><tr><th>Date</th><th>Description</th><th>Expenses</th><th>Income</th><th></th></tr></thead>
    <tbody>
    <?php if (!$financeRows): ?>
      <tr><td colspan="5" class="muted">No finance entries recorded for this month.</td></tr>
    <?php endif; ?>
    <?php foreach ($financeRows as $x): ?>
      <tr>
        <td><?= e(date('d M Y', strtotime($x['date']))) ?></td>
        <td><?= e($x['description']) ?></td>
        <td><?= $x['expense'] > 0 ? '₹'.number_format($x['expense'],2) : '-' ?></td>
        <td><?= $x['income'] > 0 ? '₹'.number_format($x['income'],2) : '-' ?></td>
        <td>
          <form method="post" onsubmit="return confirm('Delete this finance entry?')">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="finance_entry_del">
            <input type="hidden" name="entry_type" value="<?= e($x['type']) ?>">
            <input type="hidden" name="id" value="<?= $x['id'] ?>">
            <button class="btn ghost"><i class="fa fa-trash"></i></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<!-- VENDORS -->
<section id="tab-vendors" class="tab-pane">
  <h3>Add / Update Vendor</h3>
  <form method="post" enctype="multipart/form-data" class="form">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <input type="hidden" name="action" value="vendor_add">
    <div class="grid2">
      <div><label>Category</label>
        <select name="category">
          <option value="maid">Maid</option><option value="press">Press</option><option value="car_cleaner">Car Cleaner</option>
          <option value="security">Security</option><option value="housekeeping">House Keeping</option>
          <option value="other">Other</option>
        </select>
      </div>
      <div><label>Name</label><input name="name" required></div>
      <div><label>Contact number</label><input name="contact_number"></div>
      <div><label>Status</label>
        <select name="status"><option>Available</option><option>DND</option></select>
      </div>
    </div>
    <label><input type="checkbox" name="police_verified" value="1"> Police Verified</label>
    <label>Houses (comma-separated, e.g. A-101,B-204)</label>
    <input name="houses" placeholder="A-101, B-205">
    <label>Notes</label><input name="notes">
    <label>Photo</label><input type="file" name="photo" accept="image/*">
    <button class="btn primary">Save Vendor</button>
  </form>

  <h3>All Vendors</h3>
  <table class="tbl">
    <thead><tr><th>Category</th><th>Name</th><th>Phone</th><th>Verified</th><th>Status</th><th>Houses</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($vendors as $v): ?>
      <tr>
        <td><?= e(ucwords(str_replace('_',' ', $v['category']))) ?></td>
        <td><?= e($v['name']) ?></td>
        <td><?= e($v['contact_number']) ?></td>
        <td><?= $v['police_verified']?'Yes':'No' ?></td>
        <td><?= e($v['status']) ?></td>
        <td class="muted small"><?= e(implode(', ', $vhMap[$v['id']] ?? [])) ?></td>
        <td>
          <details><summary>Edit</summary>
            <form method="post" enctype="multipart/form-data" class="form">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="action" value="vendor_update">
              <input type="hidden" name="id" value="<?= $v['id'] ?>">
              <label>Name</label><input name="name" value="<?= e($v['name']) ?>">
              <label>Category</label>
              <select name="category">
                <?php foreach (['maid','press','car_cleaner','security','housekeeping','other'] as $c): ?>
                  <option value="<?= $c ?>" <?= $v['category']===$c?'selected':'' ?>><?= $c ?></option>
                <?php endforeach; ?>
              </select>
              <label>Phone</label><input name="contact_number" value="<?= e($v['contact_number']) ?>">
              <label>Status</label>
              <select name="status"><option <?= $v['status']==='Available'?'selected':'' ?>>Available</option><option <?= $v['status']==='DND'?'selected':'' ?>>DND</option></select>
              <label><input type="checkbox" name="police_verified" value="1" <?= $v['police_verified']?'checked':'' ?>> Verified</label>
              <label>Houses</label><input name="houses" value="<?= e(implode(',', $vhMap[$v['id']] ?? [])) ?>">
              <label>Notes</label><input name="notes" value="<?= e($v['notes']) ?>">
              <label>Replace photo</label><input type="file" name="photo" accept="image/*">
              <button class="btn primary">Save</button>
            </form>
          </details>
          <form method="post" onsubmit="return confirm('Delete vendor?')">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="vendor_del">
            <input type="hidden" name="id" value="<?= $v['id'] ?>">
            <button class="btn ghost"><i class="fa fa-trash"></i></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<!-- SOCIETY SPOCS -->
<section id="tab-spocs" class="tab-pane">
  <h3>Add / Update Society SPOC</h3>
  <p class="muted small">Configure department contacts visible to all residents under Society SPOCs. Multiple contacts can be added for the same department.</p>
  <form method="post" enctype="multipart/form-data" class="form">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
    <input type="hidden" name="action" value="spoc_add">
    <div class="grid2">
      <div><label>Department</label>
        <select name="department">
          <?php foreach ($spocDepartments as $d): ?><option value="<?= e($d) ?>"><?= e($d) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div><label>Name</label><input name="name" required></div>
      <div><label>Email ID</label><input type="email" name="email"></div>
      <div><label>Phone number</label><input name="phone"></div>
    </div>
    <label>Notes / Role</label><input name="notes" placeholder="Optional role or responsibility">
    <label>Photo</label><input type="file" name="photo" accept="image/*">
    <button class="btn primary">Save Society SPOC</button>
  </form>

  <h3>All Society SPOCs</h3>
  <table class="tbl">
    <thead><tr><th>Department</th><th>Photo</th><th>Name</th><th>Email</th><th>Phone</th><th>Notes</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($spocs as $srow): ?>
      <tr>
        <td><?= e($srow['department']) ?></td>
        <td><?php if ($srow['photo']): ?><img src="<?= e(upload_url($srow['photo'])) ?>" class="avatar"><?php else: ?><div class="avatar-initials"><?= e(strtoupper(substr($srow['name'],0,1))) ?></div><?php endif; ?></td>
        <td><?= e($srow['name']) ?></td>
        <td><?= e($srow['email']) ?></td>
        <td><?= e($srow['phone']) ?></td>
        <td class="muted small"><?= e($srow['notes']) ?></td>
        <td>
          <details><summary>Edit</summary>
            <form method="post" enctype="multipart/form-data" class="form">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="action" value="spoc_update">
              <input type="hidden" name="id" value="<?= $srow['id'] ?>">
              <label>Department</label>
              <select name="department">
                <?php foreach ($spocDepartments as $d): ?><option value="<?= e($d) ?>" <?= $srow['department']===$d?'selected':'' ?>><?= e($d) ?></option><?php endforeach; ?>
              </select>
              <label>Name</label><input name="name" value="<?= e($srow['name']) ?>" required>
              <label>Email ID</label><input type="email" name="email" value="<?= e($srow['email']) ?>">
              <label>Phone</label><input name="phone" value="<?= e($srow['phone']) ?>">
              <label>Notes / Role</label><input name="notes" value="<?= e($srow['notes']) ?>">
              <label>Replace photo</label><input type="file" name="photo" accept="image/*">
              <button class="btn primary">Save</button>
            </form>
          </details>
          <form method="post" onsubmit="return confirm('Delete Society SPOC?')">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="spoc_del">
            <input type="hidden" name="id" value="<?= $srow['id'] ?>">
            <button class="btn ghost"><i class="fa fa-trash"></i></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<!-- ADS -->
<section id="tab-ads" class="tab-pane">
  <h3>All Advertisements</h3>
  <table class="tbl">
    <thead><tr><th>Title</th><th>By</th><th>Price</th><th>Posted</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($ads as $a): ?>
      <tr>
        <td><?= e($a['title']) ?></td>
        <td><?= e($a['owner_name']) ?></td>
        <td><?= $a['price']!==null?'₹'.number_format($a['price'],2):'-' ?></td>
        <td class="muted small"><?= e($a['created_at']) ?></td>
        <td>
          <form method="post" onsubmit="return confirm('Delete?')">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="ad_delete">
            <input type="hidden" name="id" value="<?= $a['id'] ?>">
            <button class="btn ghost"><i class="fa fa-trash"></i></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<!-- HOUSE REQUESTS -->
<section id="tab-house-requests" class="tab-pane">
  <h3>House Number Change Requests</h3>
  <p class="muted small">Approve a request only after verifying the resident details. Approved requests are applied immediately.</p>
  <table class="tbl">
    <thead><tr><th>Resident</th><th>Current House</th><th>Requested House</th><th>Status</th><th>Reason</th><th>Admin Action</th></tr></thead>
    <tbody>
    <?php foreach ($houseRequests as $r): ?>
      <?php
        $current = resident_flat_label($r['current_tower'], $r['current_house_number']);
        if ($current === '') $current = resident_flat_label($r['user_tower'], $r['user_house_number']);
        $requested = resident_flat_label($r['requested_tower'], $r['requested_house_number']);
      ?>
      <tr>
        <td><?= e($r['owner_name']) ?><div class="muted small"><?= e($r['email']) ?></div></td>
        <td><?= e($current ?: 'Not allocated') ?></td>
        <td><b><?= e($requested) ?></b></td>
        <td><span class="badge <?= $r['status']==='approved'?'ok':($r['status']==='rejected'?'warn':'muted-badge') ?>"><?= e(ucfirst($r['status'])) ?></span><div class="muted small"><?= e($r['requested_at']) ?></div></td>
        <td class="muted small"><?= e($r['reason'] ?? '') ?></td>
        <td class="actions-cell">
          <?php if ($r['status']==='pending'): ?>
            <form method="post" onsubmit="return confirm('Approve this house number change?');">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="action" value="house_request_decide">
              <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
              <input type="hidden" name="decision" value="approve">
              <input type="text" name="admin_note" placeholder="Admin note (optional)">
              <button class="btn primary">Approve</button>
            </form>
            <form method="post" onsubmit="return confirm('Reject this house number change?');">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="action" value="house_request_decide">
              <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
              <input type="hidden" name="decision" value="reject">
              <input type="text" name="admin_note" placeholder="Reason for rejection">
              <button class="btn ghost">Reject</button>
            </form>
          <?php else: ?>
            <span class="muted small"><?= e($r['admin_note'] ?? '-') ?></span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$houseRequests): ?>
      <tr><td colspan="6" class="muted">No house number change requests yet.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</section>
<!-- USERS -->
<section id="tab-users" class="tab-pane">
  <h3>Resident Users</h3>
  <table class="tbl">
    <thead><tr><th>Name</th><th>House</th><th>Login Status</th><th>Reset Request</th><th>Ad Status</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($users as $u): ?>
      <?php
        $registered = !empty($u['password_hash']);
        $resetRequested = !empty($u['reset_requested']);
        $displayHouse = resident_flat_label($u['tower'] ?: ($u['parent_tower'] ?? ''), $u['house_number'] ?: ($u['parent_house_number'] ?? ''));
      ?>
      <tr>
        <td><?= e($u['owner_name']) ?> <span class="muted small">(<?= e($u['username']) ?>)</span></td>
        <td><?= e($displayHouse ?: 'Not allocated') ?></td>
        <td>
          <?php if ($resetRequested): ?>
            <span class="badge warn">Reset pending</span>
          <?php elseif ($registered): ?>
            <span class="badge ok">Registered</span>
          <?php else: ?>
            <span class="badge muted-badge">Not registered</span>
          <?php endif; ?>
        </td>
        <td><?= $resetRequested ? 'Requested by resident' : '-' ?></td>
        <td><?= $u['ad_restricted']?'Restricted':'Allowed' ?></td>
        <td class="actions-cell">
          <?php if ($resetRequested || $registered): ?>
            <form method="post" onsubmit="return confirm('Reset this resident password? The resident will need to register again.');">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="action" value="password_reset">
              <input type="hidden" name="uid" value="<?= $u['id'] ?>">
              <button class="btn ghost"><?= $resetRequested ? 'Reset password' : 'Force reset' ?></button>
            </form>
          <?php endif; ?>
          <form method="post">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="user_restrict">
            <input type="hidden" name="uid" value="<?= $u['id'] ?>">
            <input type="hidden" name="restrict" value="<?= $u['ad_restricted']?0:1 ?>">
            <button class="btn ghost"><?= $u['ad_restricted']?'Allow ads':'Restrict ads' ?></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>

<script>
function switchTab(el, key) {
  document.querySelectorAll('.tabs a').forEach(a => a.classList.remove('active'));
  el.classList.add('active');
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.getElementById('tab-'+key).classList.add('active');
  return false;
}
// Open tab from hash
document.addEventListener('DOMContentLoaded', () => {
  const h = location.hash.replace('#','');
  if (h) { const a = document.querySelector('.tabs a[href="#'+h+'"]'); if (a) a.click(); }
});
</script>

<?php layout_shell_end(); ?>
