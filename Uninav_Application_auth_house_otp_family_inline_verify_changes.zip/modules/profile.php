<?php
require_once __DIR__ . '/../includes/layout.php';
ensure_auth_schema();
$U = current_user();
$err = '';
$msg = flash('msg') ?: '';

$currentHome = effective_home_for_user($U);
$currentFlat = user_flat_label($U);

if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!csrf_check()) {
        $err = 'Invalid session, please try again.';
    } else {
        $a = $_POST['action'] ?? '';
        if ($a === 'update') {
            $phone = trim($_POST['phone'] ?? '');
            $name  = trim($_POST['owner_name'] ?? '');
            $photoRel = $U['photo'];
            $newPhoto = upload_file($_FILES['photo'] ?? [], 'profiles');
            if ($newPhoto) $photoRel = $newPhoto;
            db()->prepare('UPDATE users SET owner_name=?, phone=?, photo=? WHERE id=?')
                ->execute([$name,$phone,$photoRel,$U['id']]);
            $msg = 'Profile updated.';
            $U = current_user();
            $currentHome = effective_home_for_user($U);
            $currentFlat = user_flat_label($U);
        }
        if ($a === 'password') {
            $cur = $_POST['current'] ?? ''; $new=$_POST['new']??''; $c=$_POST['confirm']??'';
            if (!password_verify($cur, $U['password_hash'] ?? '')) $err='Current password is wrong.';
            elseif (strlen($new)<6) $err='New password too short.';
            elseif ($new !== $c) $err='Passwords do not match.';
            else {
                db()->prepare('UPDATE users SET password_hash=? WHERE id=?')
                    ->execute([password_hash($new, PASSWORD_DEFAULT), $U['id']]);
                $msg='Password changed.';
            }
        }
        if ($a === 'request_email_change') {
            $new = trim($_POST['new_email'] ?? '');
            if (!filter_var($new,FILTER_VALIDATE_EMAIL)) $err='Invalid email.';
            else {
                $otp = str_pad((string)random_int(0,999999),6,'0',STR_PAD_LEFT);
                db()->prepare('INSERT INTO otp_codes (email,otp,purpose,expires_at) VALUES (?,?,?,?)')
                    ->execute([$U['email'],$otp,'change_email',date('Y-m-d H:i:s', time()+600)]);
                $_SESSION['change_email_to'] = $new;
                send_mail($U['email'], 'Confirm email change',
                    "<p>Hi ".e($U['owner_name']).",</p><p>An OTP has been generated to change your email to <b>".e($new)."</b>. OTP: <b>$otp</b> (valid 10 mins).</p>");
                $msg='OTP sent to your current email.';
            }
        }
        if ($a === 'confirm_email_change') {
            $otp = trim($_POST['otp'] ?? '');
            $stmt = db()->prepare('SELECT id FROM otp_codes WHERE email=? AND otp=? AND purpose="change_email" AND used=0 AND expires_at>=NOW() ORDER BY id DESC LIMIT 1');
            $stmt->execute([$U['email'],$otp]);
            $oid = $stmt->fetchColumn();
            if (!$oid || empty($_SESSION['change_email_to'])) $err='Invalid/expired OTP.';
            else {
                $newEmail = strtolower(trim($_SESSION['change_email_to']));
                $dup = db()->prepare('SELECT id FROM users WHERE LOWER(email)=? AND id<>? LIMIT 1');
                $dup->execute([$newEmail, $U['id']]);
                if ($dup->fetchColumn()) {
                    $err = 'That email is already used by another account.';
                } else {
                    db()->prepare('UPDATE otp_codes SET used=1 WHERE id=?')->execute([$oid]);
                    db()->prepare('UPDATE users SET email=? WHERE id=?')->execute([$newEmail, $U['id']]);
                    unset($_SESSION['change_email_to']);
                    $msg = 'Email updated successfully.';
                    $U = current_user();
                }
            }
        }
        if ($a === 'request_house_change' && ($U['role'] ?? '') === 'resident') {
            $flat = trim($_POST['requested_flat'] ?? '');
            $manualTower = trim($_POST['requested_tower'] ?? '');
            $manualHouse = trim($_POST['requested_house_number'] ?? '');

            if ($flat !== '') {
                [$tower, $house] = split_flat_number($flat);
            } else {
                $tower = normalize_tower($manualTower);
                $house = normalize_house_number($manualHouse);
            }

            $reason = trim($_POST['reason'] ?? '');
            $requestedFlat = resident_flat_label($tower, $house);
            $allowedFlats = [];
            foreach (available_house_options_for_profile((int)$U['id']) as $opt) {
                $allowedFlats[resident_flat_label($opt['tower'], $opt['house_number'])] = true;
            }
            $selectedFromDropdown = $flat !== '';

            if ($tower === '' || $house === '') {
                $err = 'Please select a house from the dropdown, or enter both tower and house number separately.';
            } elseif ($selectedFromDropdown && !isset($allowedFlats[$requestedFlat])) {
                $err = 'Please choose an available tower and house number from the dropdown, or enter it manually for admin review.';
            } elseif ($requestedFlat === $currentFlat) {
                $err = 'This is already your current house number.';
            } elseif (pending_house_request_for_user((int)$U['id'])) {
                $err = 'You already have a pending house number change request.';
            } else {
                db()->prepare("INSERT INTO user_house_change_requests (user_id,current_tower,current_house_number,requested_tower,requested_house_number,reason,status) VALUES (?,?,?,?,?,?,'pending')")
                    ->execute([(int)$U['id'], $currentHome['tower'] ?? null, $currentHome['house_number'] ?? null, $tower, $house, $reason]);
                $msg = 'House number change request submitted. Admin approval is required before it is applied.';
            }
        }
    }
}

$U = current_user();
$currentHome = effective_home_for_user($U);
$currentFlat = user_flat_label($U);
$pendingHouseRequest = ($U['role'] ?? '') === 'resident' ? pending_house_request_for_user((int)$U['id']) : null;
$recentHouseRequests = [];
if (($U['role'] ?? '') === 'resident') {
    $stmt = db()->prepare("SELECT * FROM user_house_change_requests WHERE user_id=? ORDER BY id DESC LIMIT 5");
    $stmt->execute([(int)$U['id']]);
    $recentHouseRequests = $stmt->fetchAll();
}
$houseOptions = available_house_options_for_profile((int)$U['id']);

layout_shell_start('My Profile','profile');
?>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
<?php if ($msg): ?><div class="alert ok"><?= e($msg) ?></div><?php endif; ?>

<div class="grid2">
  <div class="panel">
    <h3>Profile</h3>
    <form method="post" enctype="multipart/form-data" class="form">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <input type="hidden" name="action" value="update">
      <div style="display:flex;gap:12px;align-items:center;">
        <?php if ($U['photo']): ?><img src="<?= e(upload_url($U['photo'])) ?>" class="avatar big"><?php else: ?><div class="avatar-initials big"><?= e(strtoupper(substr($U['owner_name'] ?: $U['username'],0,1))) ?></div><?php endif; ?>
        <input type="file" name="photo" accept="image/*">
      </div>
      <label>Name</label><input name="owner_name" value="<?= e($U['owner_name']) ?>">
      <label>Society</label><input value="<?= e($U['society'] ?? default_society_name()) ?>" disabled>
      <label>Username</label><input value="<?= e($U['username']) ?>" disabled>
      <label>House</label><input value="<?= e($currentFlat ?: 'Not allocated yet') ?>" disabled>
      <label>Email</label><input value="<?= e($U['email']) ?>" disabled>
      <label>Phone</label><input name="phone" value="<?= e($U['phone']) ?>">
      <button class="btn primary">Save</button>
    </form>
  </div>

  <div class="panel">
    <h3>Change Password</h3>
    <form method="post" class="form">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <input type="hidden" name="action" value="password">
      <label>Current</label><input type="password" name="current" required>
      <label>New</label><input type="password" name="new" required>
      <label>Confirm</label><input type="password" name="confirm" required>
      <button class="btn primary">Change Password</button>
    </form>

    <?php if ($U['role']==='resident'): ?>
      <hr>
      <h3>Change Email</h3>
      <form method="post" class="form">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="request_email_change">
        <label>New Email</label><input type="email" name="new_email" required>
        <button class="btn ghost">Send OTP to current email</button>
      </form>
      <?php if (!empty($_SESSION['change_email_to'])): ?>
        <form method="post" class="form" style="margin-top:8px">
          <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
          <input type="hidden" name="action" value="confirm_email_change">
          <label>OTP (to change to <?= e($_SESSION['change_email_to']) ?>)</label>
          <input name="otp" required>
          <button class="btn primary">Confirm</button>
        </form>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>

<?php if ($U['role']==='resident'): ?>
<div class="panel" style="margin-top:16px;">
  <h3>House Number Change</h3>
  <p class="muted small">If your house was not auto allocated during registration, select your tower and house number here. The portal unlocks only after admin approval.</p>

  <?php if ($pendingHouseRequest): ?>
    <div class="alert ok">
      Pending request: <?= e(resident_flat_label($pendingHouseRequest['requested_tower'], $pendingHouseRequest['requested_house_number'])) ?>.
      Please wait for admin approval.
    </div>
  <?php else: ?>
    <form method="post" class="form">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <input type="hidden" name="action" value="request_house_change">
      <label>Requested Tower &amp; House Number</label>
      <select name="requested_flat" id="requested_flat">
        <option value="">Select from available houses</option>
        <?php foreach ($houseOptions as $h): ?>
          <?php $opt = resident_flat_label($h['tower'], $h['house_number']); ?>
          <option value="<?= e($opt) ?>"><?= e($opt) ?></option>
        <?php endforeach; ?>
      </select>
      <p class="muted small">Use the dropdown if your house is listed. If it is not listed, enter tower and house number separately below.</p>

      <div class="grid2" style="gap:12px;">
        <div>
          <label>Tower</label>
          <input name="requested_tower" id="requested_tower" placeholder="Example: A">
        </div>
        <div>
          <label>House Number</label>
          <input name="requested_house_number" id="requested_house_number" placeholder="Example: 1201">
        </div>
      </div>

      <?php if (!$houseOptions): ?>
        <p class="muted small">No dropdown options are available yet. You can still enter tower and house number manually for admin review.</p>
      <?php endif; ?>
      <label>Reason / note for admin</label>
      <textarea name="reason" rows="2" placeholder="Optional"></textarea>
      <button class="btn primary">Submit for Admin Approval</button>
    </form>
    <script>
      (function(){
        var dropdown = document.getElementById('requested_flat');
        var tower = document.getElementById('requested_tower');
        var house = document.getElementById('requested_house_number');
        if (!dropdown || !tower || !house) return;
        dropdown.addEventListener('change', function(){
          if (dropdown.value) {
            tower.value = '';
            house.value = '';
          }
        });
        [tower, house].forEach(function(field){
          field.addEventListener('input', function(){
            if (tower.value.trim() || house.value.trim()) dropdown.value = '';
          });
        });
      })();
    </script>
  <?php endif; ?>

  <?php if ($recentHouseRequests): ?>
    <h4>Recent Requests</h4>
    <table class="tbl">
      <thead><tr><th>Requested House</th><th>Status</th><th>Requested On</th><th>Admin Note</th></tr></thead>
      <tbody>
      <?php foreach ($recentHouseRequests as $r): ?>
        <tr>
          <td><?= e(resident_flat_label($r['requested_tower'], $r['requested_house_number'])) ?></td>
          <td><span class="badge <?= $r['status']==='approved'?'ok':($r['status']==='rejected'?'warn':'muted-badge') ?>"><?= e(ucfirst($r['status'])) ?></span></td>
          <td class="muted small"><?= e($r['requested_at']) ?></td>
          <td class="muted small"><?= e($r['admin_note'] ?? '') ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php layout_shell_end(); ?>
