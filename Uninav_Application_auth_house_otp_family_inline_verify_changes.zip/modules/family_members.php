<?php
require_once __DIR__ . '/../includes/layout.php';
ensure_auth_schema();

$U = current_user();
$err = '';
$msg = '';
$isPrimaryResident = $U && $U['role'] === 'resident' && empty($U['parent_user_id']) && !empty($U['password_hash']);

function family_username(int $parentId, string $name): string {
    $slug = strtoupper(trim(preg_replace('/[^A-Za-z0-9]+/', '-', $name), '-'));
    if ($slug === '') $slug = 'MEMBER';
    $base = substr('FAM-' . $parentId . '-' . $slug, 0, 90);
    $username = $base;
    $n = 2;
    while (true) {
        $stmt = db()->prepare('SELECT id FROM users WHERE username=? LIMIT 1');
        $stmt->execute([$username]);
        if (!$stmt->fetchColumn()) return $username;
        $suffix = '-' . $n++;
        $username = substr($base, 0, 100 - strlen($suffix)) . $suffix;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $err = 'Invalid session, please try again.';
    } elseif (!$isPrimaryResident) {
        $err = 'Only a registered primary resident can manage family member logins.';
    } else {
        $action = $_POST['action'] ?? '';
        if ($action === 'add') {
            $name = trim($_POST['member_name'] ?? '');
            $relation = trim($_POST['member_relation'] ?? '');
            $email = strtolower(trim($_POST['member_email'] ?? ''));

            if ($name === '') {
                $err = 'Family member name is required.';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $err = 'Please enter a valid family member email address.';
            } else {
                $existing = pending_family_member_by_email($email);
                if ($existing && (int)$existing['parent_user_id'] !== (int)$U['id']) {
                    $err = 'This email is already linked to another resident account.';
                } elseif ($existing && (int)$existing['email_verified'] === 1 && !empty($existing['password_hash'])) {
                    $err = 'This family member email is already active.';
                } elseif (!$existing && resident_email_in_use($email)) {
                    $err = 'This email is already used by another resident account.';
                } else {
                    if ($existing) {
                        db()->prepare('UPDATE users SET owner_name=?, member_relation=?, email_verified=0, password_hash=NULL, reset_requested=0, society=? WHERE id=?')
                            ->execute([$name, $relation ?: null, $U['society'] ?? default_society_name(), (int)$existing['id']]);
                        $memberId = (int)$existing['id'];
                    } else {
                        $username = family_username((int)$U['id'], $name);
                        db()->prepare("INSERT INTO users (parent_user_id, username, owner_name, member_relation, email, password_hash, role, email_verified, reset_requested, society) VALUES (?,?,?,?,?,NULL,'resident',0,0,?)")
                            ->execute([(int)$U['id'], $username, $name, $relation ?: null, $email, $U['society'] ?? default_society_name()]);
                        $memberId = (int)db()->lastInsertId();
                    }

                    if (send_family_member_otp($email, $name, $U['owner_name'] ?: $U['username'])) {
                        $msg = 'Family member added. An OTP has been sent to ' . $email . '. Enter the OTP and set the password from this Family Members page.';
                    } else {
                        $err = 'Family member was saved as pending, but the OTP email could not be sent. Please check mail configuration or use Resend OTP.';
                    }
                }
            }
        } elseif ($action === 'resend_otp') {
            $memberId = (int)($_POST['member_id'] ?? 0);
            $stmt = db()->prepare('SELECT * FROM users WHERE id=? AND parent_user_id=? AND role="resident" LIMIT 1');
            $stmt->execute([$memberId, (int)$U['id']]);
            $member = $stmt->fetch();
            if (!$member || !filter_var($member['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                $err = 'Please select a valid pending family member.';
            } elseif ((int)($member['email_verified'] ?? 0) === 1 && !empty($member['password_hash'])) {
                $err = 'This family member is already active.';
            } elseif (send_family_member_otp($member['email'], $member['owner_name'] ?? '', $U['owner_name'] ?: $U['username'])) {
                $msg = 'A new OTP was sent to ' . $member['email'] . '.';
            } else {
                $err = 'Could not send OTP email right now. Please try again later.';
            }
        } elseif ($action === 'verify_otp') {
            $memberId = (int)($_POST['member_id'] ?? 0);
            $otp = preg_replace('/\D+/', '', trim($_POST['otp'] ?? ''));
            $password = $_POST['password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';

            $stmt = db()->prepare('SELECT * FROM users WHERE id=? AND parent_user_id=? AND role="resident" LIMIT 1');
            $stmt->execute([$memberId, (int)$U['id']]);
            $member = $stmt->fetch();

            if (!$member || !filter_var($member['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                $err = 'Please select a valid pending family member.';
            } elseif ((int)($member['email_verified'] ?? 0) === 1 && !empty($member['password_hash'])) {
                $err = 'This family member is already active and can login from the main login screen.';
            } elseif (strlen($otp) !== 6) {
                $err = 'Please enter the 6-digit OTP sent to the family member email.';
            } elseif (strlen($password) < 6) {
                $err = 'Password too short. Use at least 6 characters.';
            } elseif ($password !== $confirm) {
                $err = 'Passwords do not match.';
            } else {
                $stmt = db()->prepare("SELECT * FROM otp_codes WHERE email=? AND otp=? AND purpose='family_register' AND used=0 AND expires_at >= NOW() ORDER BY id DESC LIMIT 1");
                $stmt->execute([$member['email'], $otp]);
                $row = $stmt->fetch();
                if (!$row) {
                    $err = 'Invalid or expired OTP. Please resend OTP if needed.';
                } else {
                    db()->prepare('UPDATE otp_codes SET used=1 WHERE id=?')->execute([(int)$row['id']]);
                    db()->prepare('UPDATE users SET password_hash=?, email_verified=1, reset_requested=0 WHERE id=? AND parent_user_id=?')
                        ->execute([password_hash($password, PASSWORD_DEFAULT), $memberId, (int)$U['id']]);
                    $msg = 'Family member email verified and password set. They can now login from the main login screen using their email and password.';
                }
            }
        } elseif ($action === 'remove') {
            $memberId = (int)($_POST['member_id'] ?? 0);
            if ($memberId <= 0) {
                $err = 'Please select a valid family member.';
            } else {
                $stmt = db()->prepare('DELETE FROM users WHERE id=? AND parent_user_id=? AND role="resident" LIMIT 1');
                $stmt->execute([$memberId, (int)$U['id']]);
                $msg = $stmt->rowCount() ? 'Family member removed.' : 'Family member not found.';
            }
        }
    }
}

$members = [];
if ($isPrimaryResident) {
    $stmt = db()->prepare('SELECT id, owner_name, member_relation, username, email, email_verified, password_hash, created_at FROM users WHERE parent_user_id=? AND role="resident" ORDER BY owner_name');
    $stmt->execute([(int)$U['id']]);
    $members = $stmt->fetchAll();
}

layout_shell_start('Family Members', 'family_members');
?>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
<?php if ($msg): ?><div class="alert ok"><?= e($msg) ?></div><?php endif; ?>

<?php if (!$isPrimaryResident): ?>
  <div class="panel">
    <h3>Family Members</h3>
    <p class="muted">Only a registered primary resident account can add or remove family member logins.</p>
  </div>
<?php else: ?>
  <div class="grid2">
    <div class="panel">
      <h3>Add Family Member</h3>
      <p class="muted small">Add the family member email first. The app will send an OTP to that email. Enter the OTP and set the password from this Family Members page only. After verification, the family member can login from the main login screen with email and password.</p>
      <form method="post" class="form">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="add">
        <label>Family Member Name</label>
        <input type="text" name="member_name" maxlength="150" required>
        <label>Email</label>
        <input type="email" name="member_email" maxlength="150" autocomplete="email" required>
        <label>Relation (optional)</label>
        <input type="text" name="member_relation" maxlength="60" placeholder="Spouse, Parent, Child, etc.">
        <button class="btn primary" type="submit"><i class="fa fa-paper-plane"></i> Send OTP</button>
      </form>
    </div>

    <div class="panel">
      <h3>Your Family Logins</h3>
      <?php if (!$members): ?>
        <div class="empty"><i class="fa fa-users"></i><div>No family members added yet.</div></div>
      <?php else: ?>
        <table class="tbl">
          <thead><tr><th>Name</th><th>Email</th><th>Relation</th><th>Status</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($members as $m): ?>
            <?php $active = (int)($m['email_verified'] ?? 0) === 1 && !empty($m['password_hash']); ?>
            <tr>
              <td><b><?= e($m['owner_name']) ?></b><div class="small muted"><?= e($m['username']) ?></div></td>
              <td><?= e($m['email'] ?: '-') ?></td>
              <td><?= e($m['member_relation'] ?: '-') ?></td>
              <td>
                <?php if ($active): ?>
                  <span class="badge ok">Active</span>
                <?php else: ?>
                  <span class="badge warn">Pending OTP/password</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if (!$active): ?>
                  <form method="post" style="display:inline">
                    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                    <input type="hidden" name="action" value="resend_otp">
                    <input type="hidden" name="member_id" value="<?= (int)$m['id'] ?>">
                    <button class="btn ghost" type="submit"><i class="fa fa-envelope"></i> Resend OTP</button>
                  </form>
                <?php endif; ?>
                <form method="post" style="display:inline" onsubmit="return confirm('Remove this family member login?');">
                  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                  <input type="hidden" name="action" value="remove">
                  <input type="hidden" name="member_id" value="<?= (int)$m['id'] ?>">
                  <button class="btn ghost" type="submit"><i class="fa fa-trash"></i> Remove</button>
                </form>
              </td>
            </tr>
            <?php if (!$active): ?>
              <tr class="family-verify-row">
                <td colspan="5">
                  <form method="post" class="family-verify-form">
                    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                    <input type="hidden" name="action" value="verify_otp">
                    <input type="hidden" name="member_id" value="<?= (int)$m['id'] ?>">
                    <div class="small muted">Enter the OTP sent to <b><?= e($m['email']) ?></b> and set this family member's password. After this, they login only from the main login screen.</div>
                    <div class="family-verify-fields">
                      <div>
                        <label>Verification Code</label>
                        <input type="text" name="otp" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" placeholder="6-digit OTP" required>
                      </div>
                      <div>
                        <label>Set Password</label>
                        <input type="password" name="password" minlength="6" autocomplete="new-password" required>
                      </div>
                      <div>
                        <label>Confirm Password</label>
                        <input type="password" name="confirm_password" minlength="6" autocomplete="new-password" required>
                      </div>
                      <div class="family-verify-submit">
                        <button class="btn primary" type="submit"><i class="fa fa-check"></i> Verify &amp; Activate</button>
                      </div>
                    </div>
                  </form>
                </td>
              </tr>
            <?php endif; ?>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
<?php endif; ?>

<?php layout_shell_end(); ?>
