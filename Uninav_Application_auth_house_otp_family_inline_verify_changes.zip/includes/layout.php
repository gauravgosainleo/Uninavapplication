<?php
// Layout helpers - header, sidebar, footer
require_once __DIR__ . '/helpers.php';
require_login();

$U    = current_user();
ensure_auth_schema();
$houseLocked = resident_needs_house_setup($U);
$currentScript = basename(parse_url($_SERVER['SCRIPT_NAME'] ?? '', PHP_URL_PATH) ?: '');
if ($houseLocked && $currentScript !== 'profile.php') {
    flash('msg', 'Please select your tower and house number from Profile. Other options will unlock after admin approval.');
    redirect('modules/profile.php');
}
$nav  = [
    'calendar'       => ['Event Calendar',     'calendar-days'],
    'notices'        => ['Society Notices',    'bullhorn'],
    'complaints'     => ['Complaints',         'circle-exclamation'],
    'finance'        => ['Finance & Expenses', 'indian-rupee-sign'],
    'vendors'        => ['Third-party Vendors','people-carry-box'],
    'spocs'          => ['Society SPOCs',      'address-book'],
    'ads'            => ['Society Ads',        'rectangle-ad'],
    'polls'          => ['Society Polls',      'square-poll-vertical'],
    'family_members' => ['Family Members',     'users'],
];
$current = $current ?? 'calendar';

function layout_head($title) {
    global $U;
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js" defer></script>
</head><body class="app-body">
<?php }

function layout_shell_start($title, $currentKey) {
    global $U, $nav, $houseLocked;
    layout_head($title);
?>
<div class="app">
  <aside class="sidebar">
    <div class="sb-brand"><div class="logo">UV</div><div><b>Uni-Vishwas</b><div class="muted small">Society Portal</div></div></div>
    <nav class="sb-nav">
      <?php foreach ($nav as $key => [$label, $icon]): ?>
        <?php $disabled = $houseLocked && $U['role']==='resident'; ?>
        <?php if ($disabled): ?>
          <a href="#" class="disabled" aria-disabled="true" tabindex="-1" title="Set up your tower and house number from Profile to unlock this option">
            <i class="fa fa-<?= e($icon) ?>"></i>
            <span><?= e($label) ?></span>
          </a>
        <?php else: ?>
          <a href="<?= APP_URL ?>/modules/<?= $key ?>.php" class="<?= $currentKey===$key?'active':'' ?>">
            <i class="fa fa-<?= e($icon) ?>"></i>
            <span><?= e($label) ?></span>
          </a>
        <?php endif; ?>
      <?php endforeach; ?>
      <?php if ($U['role']==='admin'): ?>
        <a href="<?= APP_URL ?>/modules/settings.php" class="<?= $currentKey==='settings'?'active':'' ?>">
          <i class="fa fa-gear"></i><span>Settings</span>
        </a>
      <?php endif; ?>
    </nav>
    <div class="sb-footer muted small">v1.0</div>
  </aside>
  <main class="main">
    <header class="topbar">
      <div class="topbar-title"><?= e($title) ?></div>
      <div class="profile" onclick="this.classList.toggle('open')">
        <?php $photo = $U['photo'] ?? null; ?>
        <?php if ($photo): ?>
          <img src="<?= e(upload_url($photo)) ?>" alt="" class="avatar">
        <?php else: ?>
          <div class="avatar-initials"><?= e(strtoupper(substr($U['owner_name'] ?: $U['username'],0,1))) ?></div>
        <?php endif; ?>
        <div class="who">
          <b><?= e($U['owner_name'] ?: $U['username']) ?></b>
          <?php $flatLabel = user_flat_label($U); ?>
          <div class="muted small"><?= e(!empty($U['parent_user_id']) ? 'Family Member' : ucfirst($U['role'])) ?><?= $flatLabel ? ' · '.e($flatLabel) : '' ?></div>
        </div>
        <i class="fa fa-chevron-down"></i>
        <div class="dropdown">
          <a href="<?= APP_URL ?>/modules/profile.php"><i class="fa fa-user"></i> My Profile</a>
          <a href="<?= APP_URL ?>/auth/logout.php"><i class="fa fa-sign-out"></i> Logout</a>
        </div>
      </div>
    </header>
    <section class="content">
      <?php if (!empty($houseLocked) && $U['role']==='resident'): ?>
        <div class="alert warn house-lock-alert">
          <b>House setup required.</b> Your tower and house number are not configured yet. Select them from Profile and wait for admin approval to unlock the portal options.
        </div>
      <?php endif; ?>
<?php }

function layout_shell_end() {
?>
    </section>
  </main>
</div>
<script src="<?= APP_URL ?>/assets/js/app.js"></script>
</body></html>
<?php }
