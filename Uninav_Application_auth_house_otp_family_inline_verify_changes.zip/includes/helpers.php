<?php
require_once __DIR__ . '/../config/db.php';

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function redirect($path) {
    header('Location: ' . APP_URL . '/' . ltrim($path, '/'));
    exit;
}

function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function require_login() {
    if (!is_logged_in()) redirect('auth/login.php');
}

function require_admin() {
    require_login();
    $u = current_user();
    if (!$u || $u['role'] !== 'admin') {
        http_response_code(403);
        die('Access denied. Admins only.');
    }
}

function is_admin(): bool {
    $u = current_user();
    return $u && $u['role'] === 'admin';
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['csrf'];
}

function csrf_check(): bool {
    $t = $_POST['csrf'] ?? $_GET['csrf'] ?? '';
    return hash_equals($_SESSION['csrf'] ?? '', $t);
}

function flash($key, $msg = null) {
    if ($msg === null) {
        $m = $_SESSION['flash'][$key] ?? null;
        unset($_SESSION['flash'][$key]);
        return $m;
    }
    $_SESSION['flash'][$key] = $msg;
}

function upload_file(array $file, string $subdir): ?string {
    if (empty($file['name']) || $file['error'] !== UPLOAD_ERR_OK) return null;
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png','gif','webp'];
    if (!in_array($ext, $allowed, true)) return null;
    $dir = UPLOAD_DIR . '/' . $subdir;
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    $dest = $dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $dest)) return null;
    return $subdir . '/' . $name;
}

function upload_url($rel) {
    return $rel ? UPLOAD_URL . '/' . $rel : '';
}

function send_mail(string $to, string $subject, string $html, array $extraHeaders = []): bool {
    $headers  = [];
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-Type: text/html; charset=UTF-8';
    $headers[] = 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . '>';
    $headers[] = 'Reply-To: ' . MAIL_FROM;
    foreach ($extraHeaders as $h) $headers[] = $h;
    return @mail($to, $subject, $html, implode("\r\n", $headers));
}

function months_ago($n = 12): array {
    $out = [];
    for ($i = 0; $i < $n; $i++) {
        $t = strtotime("-$i months");
        $out[] = date('Y-m', $t);
    }
    return $out;
}

function uv_column_exists(string $table, string $column): bool {
    $stmt = db()->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function uv_table_exists(string $table): bool {
    $stmt = db()->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
    $stmt->execute([$table]);
    return (int)$stmt->fetchColumn() > 0;
}

function uv_index_exists(string $table, string $index): bool {
    $stmt = db()->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?');
    $stmt->execute([$table, $index]);
    return (int)$stmt->fetchColumn() > 0;
}

function ensure_family_schema(): void {
    static $done = false;
    if ($done) return;
    $pdo = db();
    if (!uv_column_exists('users', 'parent_user_id')) {
        $pdo->exec('ALTER TABLE users ADD COLUMN parent_user_id INT NULL AFTER id');
    }
    if (!uv_column_exists('users', 'member_relation')) {
        $pdo->exec('ALTER TABLE users ADD COLUMN member_relation VARCHAR(60) NULL AFTER owner_name');
    }
    if (!uv_index_exists('users', 'idx_parent_user_id')) {
        $pdo->exec('ALTER TABLE users ADD INDEX idx_parent_user_id (parent_user_id)');
    }
    $done = true;
}

function ensure_auth_schema(): void {
    static $done = false;
    if ($done) return;
    ensure_family_schema();
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS otp_codes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(150) NOT NULL,
        otp VARCHAR(10) NOT NULL,
        purpose ENUM('register','family_register','reset','change_email') NOT NULL DEFAULT 'register',
        expires_at DATETIME NOT NULL,
        used TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_otp_email (email),
        INDEX idx_otp_code (otp)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    try {
        $pdo->exec("ALTER TABLE otp_codes MODIFY purpose ENUM('register','family_register','reset','change_email') NOT NULL DEFAULT 'register'");
    } catch (Throwable $ignored) {
        // Some hosts restrict enum modification. Fresh installs already include family_register.
    }
    if (!uv_column_exists('users', 'society')) {
        $pdo->exec("ALTER TABLE users ADD COLUMN society VARCHAR(120) NOT NULL DEFAULT 'Uninav Heights' AFTER house_number");
    }
    if (!uv_index_exists('users', 'idx_users_email_role')) {
        $pdo->exec('ALTER TABLE users ADD INDEX idx_users_email_role (email, role)');
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_house_change_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        current_tower VARCHAR(20) NULL,
        current_house_number VARCHAR(20) NULL,
        requested_tower VARCHAR(20) NOT NULL,
        requested_house_number VARCHAR(20) NOT NULL,
        reason TEXT NULL,
        status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
        admin_id INT NULL,
        admin_note TEXT NULL,
        requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        decided_at DATETIME NULL,
        INDEX idx_house_change_status (status),
        INDEX idx_house_change_user (user_id),
        INDEX idx_house_change_requested (requested_tower, requested_house_number)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done = true;
}

function effective_home_for_user(array $user): array {
    if (!empty($user['tower']) || !empty($user['house_number'])) {
        return ['tower' => $user['tower'] ?? '', 'house_number' => $user['house_number'] ?? ''];
    }
    if (!empty($user['parent_user_id'])) {
        ensure_family_schema();
        $stmt = db()->prepare('SELECT tower, house_number FROM users WHERE id=? LIMIT 1');
        $stmt->execute([(int)$user['parent_user_id']]);
        $parent = $stmt->fetch() ?: [];
        return ['tower' => $parent['tower'] ?? '', 'house_number' => $parent['house_number'] ?? ''];
    }
    return ['tower' => '', 'house_number' => ''];
}

function user_flat_label(array $user): string {
    $home = effective_home_for_user($user);
    return resident_flat_label($home['tower'] ?? '', $home['house_number'] ?? '');
}

function resident_house_configured(array $user): bool {
    if (($user['role'] ?? '') !== 'resident') return true;
    $home = effective_home_for_user($user);
    return normalize_tower($home['tower'] ?? '') !== '' && normalize_house_number($home['house_number'] ?? '') !== '';
}

function resident_needs_house_setup(?array $user): bool {
    return $user && ($user['role'] ?? '') === 'resident' && !resident_house_configured($user);
}

function available_house_options_for_profile(int $userId = 0): array {
    ensure_auth_schema();
    $sql = "SELECT DISTINCT tower, house_number
            FROM users
            WHERE role='resident'
              AND tower IS NOT NULL AND tower<>''
              AND house_number IS NOT NULL AND house_number<>''
              AND (id=? OR password_hash IS NULL OR password_hash='' OR email IS NULL OR email='')
            ORDER BY tower, CAST(house_number AS UNSIGNED), house_number";
    $stmt = db()->prepare($sql);
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

function normalize_tower($tower): string {
    return strtoupper(trim(preg_replace('/\s+/', '', (string)$tower)));
}

function normalize_house_number($house): string {
    return strtoupper(trim(preg_replace('/\s+/', '', (string)$house)));
}

function resident_username($tower, $house): string {
    $tower = preg_replace('/[^A-Z0-9]+/', '-', normalize_tower($tower));
    $house = preg_replace('/[^A-Z0-9]+/', '-', normalize_house_number($house));
    $tower = trim($tower, '-');
    $house = trim($house, '-');
    return substr('RES-' . $tower . '-' . $house, 0, 100);
}

function normalize_flat_number($flat): string {
    $flat = strtoupper(trim((string)$flat));
    $flat = str_replace(['–', '—', '_', '/'], '-', $flat);
    $flat = preg_replace('/\s*-\s*/', '-', $flat);
    $flat = preg_replace('/\s+/', '', $flat);
    return trim($flat, '-');
}

function split_flat_number($flat): array {
    $flat = normalize_flat_number($flat);
    if ($flat === '') return ['', ''];
    if (strpos($flat, '-') !== false) {
        [$tower, $house] = array_pad(explode('-', $flat, 2), 2, '');
    } elseif (preg_match('/^([A-Z]+)([0-9].*)$/', $flat, $m)) {
        $tower = $m[1];
        $house = $m[2];
    } else {
        return ['', normalize_house_number($flat)];
    }
    return [normalize_tower($tower), normalize_house_number($house)];
}

function resident_flat_label($tower, $house): string {
    $tower = normalize_tower($tower);
    $house = normalize_house_number($house);
    return $tower !== '' && $house !== '' ? $tower . '-' . $house : trim($tower . $house);
}

function default_society_name(): string {
    return 'Uninav Heights';
}

function normalize_person_name($name): string {
    $name = strtoupper((string)$name);
    $name = preg_replace('/[^A-Z0-9\s]/', ' ', $name);
    $parts = preg_split('/\s+/', trim($name));
    $titles = ['MR','MRS','MS','MISS','DR','SHRI','SMT','SRI','PROF','CAPT','MAJOR','COL'];
    while ($parts && in_array($parts[0], $titles, true)) {
        array_shift($parts);
    }
    return trim(preg_replace('/\s+/', ' ', implode(' ', $parts)));
}

function unique_username(string $base): string {
    $base = strtoupper($base);
    $base = preg_replace('/[^A-Z0-9._-]+/', '-', $base);
    $base = trim($base, '-._');
    if ($base === '') $base = 'USER';
    $base = substr($base, 0, 90);
    $username = $base;
    $n = 2;
    while (true) {
        $stmt = db()->prepare('SELECT id FROM users WHERE username=? LIMIT 1');
        $stmt->execute([$username]);
        if (!$stmt->fetchColumn()) return $username;
        $suffix = '-' . $n++;
        $username = substr($base, 0, 100 - strlen($suffix)) . $suffix;
    }
}

function username_from_email(string $email): string {
    $local = explode('@', $email)[0] ?? 'USER';
    return unique_username('USR-' . $local);
}

function find_resident_matches_by_name(string $name): array {
    $needle = normalize_person_name($name);
    if ($needle === '') return [];
    $rows = db()->query("SELECT * FROM users WHERE role='resident' AND parent_user_id IS NULL AND tower IS NOT NULL AND tower<>'' AND house_number IS NOT NULL AND house_number<>'' ORDER BY tower, CAST(house_number AS UNSIGNED), house_number, id")->fetchAll();
    $matches = [];
    foreach ($rows as $row) {
        if (normalize_person_name($row['owner_name'] ?? '') === $needle) $matches[] = $row;
    }
    return $matches;
}

function pending_house_request_for_user(int $userId): ?array {
    ensure_auth_schema();
    $stmt = db()->prepare("SELECT * FROM user_house_change_requests WHERE user_id=? AND status='pending' ORDER BY id DESC LIMIT 1");
    $stmt->execute([$userId]);
    return $stmt->fetch() ?: null;
}
function generate_otp_code(): string {
    return str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

function create_email_otp(string $email, string $purpose = 'register', int $ttlSeconds = 600): string {
    ensure_auth_schema();
    $otp = generate_otp_code();
    db()->prepare('INSERT INTO otp_codes (email, otp, purpose, expires_at) VALUES (?,?,?,?)')
        ->execute([$email, $otp, $purpose, date('Y-m-d H:i:s', time() + $ttlSeconds)]);
    return $otp;
}

function send_registration_otp(string $email, string $name = ''): bool {
    $otp = create_email_otp($email, 'register', 600);
    $safeName = trim($name) !== '' ? e($name) : 'Resident';
    $html = '<p>Hello ' . $safeName . ',</p>'
        . '<p>Your ' . e(default_society_name()) . ' registration OTP is:</p>'
        . '<p style="font-size:24px;font-weight:bold;letter-spacing:4px;">' . e($otp) . '</p>'
        . '<p>This code expires in 10 minutes. If you did not request this registration, please ignore this email.</p>';
    return send_mail($email, 'Your ' . default_society_name() . ' registration OTP', $html);
}

function send_family_member_otp(string $email, string $memberName = '', string $parentName = ''): bool {
    $otp = create_email_otp($email, 'family_register', 600);
    $safeName = trim($memberName) !== '' ? e($memberName) : 'Family Member';
    $safeParent = trim($parentName) !== '' ? e($parentName) : 'the primary resident';
    $html = '<p>Hello ' . $safeName . ',</p>'
        . '<p>' . $safeParent . ' has added you as a family member in the ' . e(default_society_name()) . ' portal.</p>'
        . '<p>Your email verification OTP is:</p>'
        . '<p style="font-size:24px;font-weight:bold;letter-spacing:4px;">' . e($otp) . '</p>'
        . '<p>This code expires in 10 minutes. Ask the primary resident to enter this OTP in the Family Members option and set your password there.</p>'
        . '<p>After verification, use the main login screen with this email address and your password.</p>'
        . '<p>If you did not expect this invitation, please ignore this email.</p>';
    return send_mail($email, 'Verify your ' . default_society_name() . ' family member login', $html);
}

function pending_family_member_by_email(string $email): ?array {
    ensure_auth_schema();
    $stmt = db()->prepare("SELECT * FROM users WHERE LOWER(email)=? AND role='resident' AND parent_user_id IS NOT NULL LIMIT 1");
    $stmt->execute([strtolower(trim($email))]);
    return $stmt->fetch() ?: null;
}

function resident_email_in_use(string $email, int $excludeUserId = 0): bool {
    $email = strtolower(trim($email));
    $sql = "SELECT id FROM users WHERE LOWER(email)=? AND role='resident'";
    $params = [$email];
    if ($excludeUserId > 0) {
        $sql .= ' AND id<>?';
        $params[] = $excludeUserId;
    }
    $sql .= ' LIMIT 1';
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return (bool)$stmt->fetchColumn();
}

function complete_pending_resident_registration(array $pending): array {
    ensure_auth_schema();
    $name = trim((string)($pending['name'] ?? ''));
    $email = strtolower(trim((string)($pending['email'] ?? '')));
    $hash = (string)($pending['password_hash'] ?? '');
    $society = default_society_name();

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $hash === '') {
        throw new RuntimeException('Registration session expired or is incomplete. Please register again.');
    }

    $stmt = db()->prepare("SELECT id, password_hash, email_verified FROM users WHERE LOWER(email)=? AND role='resident' LIMIT 1");
    $stmt->execute([$email]);
    $existing = $stmt->fetch();
    if ($existing && !empty($existing['password_hash']) && (int)($existing['email_verified'] ?? 0) === 1) {
        throw new RuntimeException('This email is already registered. Please login.');
    }

    $matches = find_resident_matches_by_name($name);
    $candidate = null;
    if (count($matches) === 1) {
        $candidate = $matches[0];
        if (!empty($candidate['password_hash']) && strtolower((string)$candidate['email']) !== $email) {
            $candidate = null;
        }
    }

    if ($candidate) {
        db()->prepare("UPDATE users SET owner_name=?, email=?, password_hash=?, email_verified=1, reset_requested=0, society=? WHERE id=?")
            ->execute([$name, $email, $hash, $society, (int)$candidate['id']]);
        $stmt = db()->prepare('SELECT * FROM users WHERE id=? LIMIT 1');
        $stmt->execute([(int)$candidate['id']]);
        $u = $stmt->fetch();
        return [
            'user' => $u,
            'auto_allocated' => true,
            'message' => 'Registration successful. Your email was verified and your house number was auto allocated as ' . user_flat_label($u) . '.'
        ];
    }

    if ($existing) {
        db()->prepare("UPDATE users SET owner_name=?, email=?, password_hash=?, email_verified=1, reset_requested=0, society=? WHERE id=?")
            ->execute([$name, $email, $hash, $society, (int)$existing['id']]);
        $newId = (int)$existing['id'];
    } else {
        $username = username_from_email($email);
        db()->prepare("INSERT INTO users (username, owner_name, email, password_hash, role, email_verified, reset_requested, society) VALUES (?,?,?,?, 'resident', 1, 0, ?)")
            ->execute([$username, $name, $email, $hash, $society]);
        $newId = (int)db()->lastInsertId();
    }

    $stmt = db()->prepare('SELECT * FROM users WHERE id=? LIMIT 1');
    $stmt->execute([$newId]);
    $u = $stmt->fetch();
    return [
        'user' => $u,
        'auto_allocated' => false,
        'message' => 'Registration successful. Your email was verified. We could not auto allocate a house number from your name, so please request the correct house number below. Admin approval is required.'
    ];
}
