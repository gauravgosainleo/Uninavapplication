<?php
require_once __DIR__ . '/../includes/helpers.php';
flash('msg', 'Family member verification is handled inside the Family Members option. After verification, family members can login here using email and password.');
redirect('auth/login.php');
