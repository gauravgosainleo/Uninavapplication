<?php
require_once __DIR__ . '/../includes/helpers.php';
ensure_auth_schema();
if (is_logged_in()) redirect('dashboard.php');

$err = '';
$name = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $err = 'Invalid session, please try again.';
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if ($name === '') {
            $err = 'Name is required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $err = 'Please enter a valid email address.';
        } elseif (strlen($password) < 6) {
            $err = 'Password too short. Use at least 6 characters.';
        } elseif ($password !== $confirmPassword) {
            $err = 'Passwords do not match.';
        } else {
            $stmt = db()->prepare("SELECT id, password_hash, email_verified FROM users WHERE LOWER(email)=? AND role='resident' LIMIT 1");
            $stmt->execute([$email]);
            $existing = $stmt->fetch();
            if ($existing && !empty($existing['password_hash']) && (int)($existing['email_verified'] ?? 0) === 1) {
                $err = 'This email is already registered. Please login.';
            } else {
                $_SESSION['pending_registration'] = [
                    'name' => $name,
                    'email' => $email,
                    'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                    'society' => default_society_name(),
                    'created_at' => time(),
                ];
                $_SESSION['pending_email'] = $email;
                unset($_SESSION['reset_email'], $_SESSION['reset_verified']);

                if (send_registration_otp($email, $name)) {
                    flash('msg', 'We sent a 6-digit OTP to your email. Please verify it to complete registration.');
                    redirect('auth/verify_otp.php');
                }
                $err = 'Could not send OTP email right now. Please check the mail configuration and try again.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Registration - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body class="auth-body">
<div class="auth-wrap">
  <div class="auth-card">
    <div class="brand">
      <div class="logo">UV</div>
      <h1>Resident Registration</h1>
      <p class="muted">Society is hardcoded as <?= e(default_society_name()) ?>. After you submit, an OTP will be sent to your email for verification.</p>
    </div>

    <div class="auth-actions" style="margin-bottom:14px;">
      <a class="btn ghost" href="<?= APP_URL ?>/auth/login.php">Login</a>
      <a class="btn primary" href="<?= APP_URL ?>/auth/register.php">Registration</a>
    </div>

    <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>

    <form method="post" class="form">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <label>Name</label>
      <input type="text" name="name" value="<?= e($name) ?>" autocomplete="name" required autofocus>

      <label>Society</label>
      <input type="text" value="<?= e(default_society_name()) ?>" readonly>

      <label>Email</label>
      <input type="email" name="email" value="<?= e($email) ?>" autocomplete="email" required>
      <p class="muted small">We will send a one-time password to this email to verify it.</p>

      <div class="grid2">
        <div>
          <label>Password</label>
          <input type="password" name="password" autocomplete="new-password" required>
        </div>
        <div>
          <label>Confirm Password</label>
          <input type="password" name="confirm_password" autocomplete="new-password" required>
        </div>
      </div>

      <button class="btn primary full" type="submit">Send OTP &amp; Register</button>
    </form>

    <div class="auth-links">
      <a href="<?= APP_URL ?>/auth/login.php">Already registered? Login here</a>
    </div>
  </div>
</div>
</body>
</html>
