<?php
require_once __DIR__ . '/../includes/helpers.php';
ensure_auth_schema();
if (is_logged_in()) redirect('dashboard.php');

$err = '';
$msg = flash('msg');

function set_login_session(array $u): void {
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$u['id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $err = 'Invalid session, please try again.';
    } else {
        $action = $_POST['action'] ?? 'resident_login';

        if ($action === 'admin_login') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['admin_password'] ?? '';
            $stmt = db()->prepare("SELECT * FROM users WHERE username=? AND role='admin' LIMIT 1");
            $stmt->execute([$username]);
            $u = $stmt->fetch();
            if ($u && !empty($u['password_hash']) && password_verify($password, $u['password_hash'])) {
                set_login_session($u);
                redirect('dashboard.php');
            } else {
                $err = 'Invalid admin credentials.';
            }
        }

        if ($action === 'resident_login') {
            $email = strtolower(trim($_POST['email'] ?? ''));
            $password = $_POST['password'] ?? '';
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $err = 'Please enter a valid email address.';
            } else {
                $stmt = db()->prepare("SELECT * FROM users WHERE LOWER(email)=? AND role='resident' AND password_hash IS NOT NULL AND password_hash<>'' LIMIT 1");
                $stmt->execute([$email]);
                $u = $stmt->fetch();
                if ($u && !empty($u['password_hash']) && password_verify($password, $u['password_hash'])) {
                    if ((int)($u['email_verified'] ?? 0) !== 1) {
                        $err = 'Please verify your email with OTP before logging in.';
                    } else {
                        set_login_session($u);
                        redirect('dashboard.php');
                    }
                } else {
                    $err = 'Invalid email or password.';
                }
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body class="auth-body">
<div class="auth-wrap">
  <div class="auth-card">
    <div class="brand">
      <div class="logo">UV</div>
      <h1>Welcome to <?= e(default_society_name()) ?></h1>
      <p class="muted">Login with your registered email or create a new resident account.</p>
    </div>

    <div class="auth-actions" style="margin-bottom:14px;">
      <a class="btn primary" href="<?= APP_URL ?>/auth/login.php">Login</a>
      <a class="btn ghost" href="<?= APP_URL ?>/auth/register.php">Registration</a>
    </div>

    <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
    <?php if ($msg): ?><div class="alert ok"><?= e($msg) ?></div><?php endif; ?>

    <form method="post" class="form">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <input type="hidden" name="action" value="resident_login">
      <label>Email</label>
      <input type="email" name="email" autocomplete="username" required autofocus>
      <label>Password</label>
      <input type="password" name="password" autocomplete="current-password" required>
      <button class="btn primary full" type="submit">Login</button>
    </form>

    <div class="auth-links">
      <a href="<?= APP_URL ?>/auth/register.php">New user? Register here</a>
    </div>

    <div class="auth-divider"><span>Admin access</span></div>
    <details class="admin-details">
      <summary>Login as admin</summary>
      <form method="post" class="form admin-form">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="admin_login">
        <label>Username</label>
        <input type="text" name="username" autocomplete="username" required>
        <label>Password</label>
        <input type="password" name="admin_password" autocomplete="current-password" required>
        <button class="btn primary" type="submit">Login</button>
      </form>
    </details>
  </div>
</div>
</body>
</html>
