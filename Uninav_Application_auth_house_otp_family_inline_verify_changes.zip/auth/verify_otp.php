<?php
require_once __DIR__ . '/../includes/helpers.php';
ensure_auth_schema();

$hasPendingRegistration = !empty($_SESSION['pending_registration']) && !empty($_SESSION['pending_registration']['email']);
$hasPendingEmail = !empty($_SESSION['pending_email']);
$hasResetEmail = !empty($_SESSION['reset_email']);

if (!$hasPendingRegistration && !$hasPendingEmail && !$hasResetEmail) redirect('auth/login.php');

$purpose = $hasResetEmail ? 'reset' : 'register';
$email = $hasResetEmail ? $_SESSION['reset_email'] : ($hasPendingRegistration ? $_SESSION['pending_registration']['email'] : $_SESSION['pending_email']);
$name = $hasPendingRegistration ? ($_SESSION['pending_registration']['name'] ?? '') : '';

$err = $msg = '';
$pageMsg = flash('msg');

function set_verified_registration_session(array $u): void {
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$u['id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $err = 'Invalid session.';
    } else {
        $action = $_POST['action'] ?? 'verify';
        if ($action === 'resend') {
            if ($purpose === 'register') {
                $sent = send_registration_otp($email, $name);
            } else {
                $new = create_email_otp($email, 'reset', 600);
                $sent = send_mail($email, 'Your Uninav OTP', '<p>Your OTP is <b>' . e($new) . '</b>. Expires in 10 minutes.</p>');
            }
            $msg = $sent ? 'A new OTP was sent to your email.' : 'Could not send OTP email right now. Please try again later.';
        } else {
            $otp = preg_replace('/\D+/', '', trim($_POST['otp'] ?? ''));
            if (strlen($otp) !== 6) {
                $err = 'Please enter the 6-digit OTP.';
            } else {
                $stmt = db()->prepare('SELECT * FROM otp_codes WHERE email=? AND otp=? AND purpose=? AND used=0 AND expires_at >= NOW() ORDER BY id DESC LIMIT 1');
                $stmt->execute([$email, $otp, $purpose]);
                $row = $stmt->fetch();
                if (!$row) {
                    $err = 'Invalid or expired OTP.';
                } else {
                    db()->prepare('UPDATE otp_codes SET used=1 WHERE id=?')->execute([$row['id']]);
                    if ($purpose === 'register') {
                        try {
                            if ($hasPendingRegistration) {
                                $result = complete_pending_resident_registration($_SESSION['pending_registration']);
                                unset($_SESSION['pending_registration'], $_SESSION['pending_email']);
                                flash('msg', $result['message']);
                                set_verified_registration_session($result['user']);
                                redirect('modules/profile.php');
                            }
                            db()->prepare('UPDATE users SET email_verified=1 WHERE email=? AND role="resident"')->execute([$email]);
                            unset($_SESSION['pending_email']);
                            flash('msg', 'Email verified! Please login.');
                            redirect('auth/login.php');
                        } catch (Throwable $ex) {
                            $err = $ex->getMessage();
                        }
                    } else {
                        $_SESSION['reset_verified'] = true;
                        redirect('auth/reset_password.php');
                    }
                }
            }
        }
    }
}
?>
<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Verify Email OTP - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css"></head>
<body class="auth-body">
<div class="auth-wrap"><div class="auth-card">
<div class="brand"><div class="logo">UV</div><h1>Verify Email OTP</h1>
<p class="muted">We sent a 6-digit code to <b><?= e($email) ?></b>. It expires in 10 minutes.</p></div>
<?php if ($pageMsg): ?><div class="alert ok"><?= e($pageMsg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
<?php if ($msg && !$err): ?><div class="alert ok"><?= e($msg) ?></div><?php endif; ?>
<form method="post" class="form">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
  <input type="hidden" name="action" value="verify">
  <label>Enter OTP</label>
  <input type="text" name="otp" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" required autofocus>
  <button class="btn primary">Verify Email</button>
</form>
<form method="post" class="form" style="margin-top:8px;">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
  <input type="hidden" name="action" value="resend">
  <button class="btn ghost">Resend OTP</button>
</form>
<div class="auth-links"><a href="<?= $purpose === 'register' ? 'register.php' : 'login.php' ?>"><?= $purpose === 'register' ? 'Back to registration' : 'Back to login' ?></a></div>
</div></div>
</body></html>
