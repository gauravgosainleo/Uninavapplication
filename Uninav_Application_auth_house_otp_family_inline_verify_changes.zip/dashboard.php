<?php
require_once __DIR__ . '/includes/helpers.php';
require_login();
ensure_auth_schema();
$u = current_user();
if (resident_needs_house_setup($u)) {
    flash('msg', 'Please select your tower and house number from Profile. Other options will unlock after admin approval.');
    redirect('modules/profile.php');
}
redirect('modules/calendar.php');
