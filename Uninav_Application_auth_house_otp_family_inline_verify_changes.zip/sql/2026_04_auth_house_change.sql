-- Migration: email/password resident registration, OTP email verification, and admin-approved house changes

CREATE TABLE IF NOT EXISTS otp_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) NOT NULL,
    otp VARCHAR(10) NOT NULL,
    purpose ENUM('register','family_register','reset','change_email') NOT NULL DEFAULT 'register',
    expires_at DATETIME NOT NULL,
    used TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_otp_email (email),
    INDEX idx_otp_code (otp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS society VARCHAR(120) NOT NULL DEFAULT 'Uninav Heights' AFTER house_number;

CREATE INDEX IF NOT EXISTS idx_users_email_role ON users (email, role);

CREATE TABLE IF NOT EXISTS user_house_change_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    current_tower VARCHAR(20) NULL,
    current_house_number VARCHAR(20) NULL,
    requested_tower VARCHAR(20) NOT NULL,
    requested_house_number VARCHAR(20) NOT NULL,
    reason TEXT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    admin_id INT NULL,
    admin_note TEXT NULL,
    requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    decided_at DATETIME NULL,
    INDEX idx_house_change_status (status),
    INDEX idx_house_change_user (user_id),
    INDEX idx_house_change_requested (requested_tower, requested_house_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add OTP purpose used for family member email verification.
ALTER TABLE otp_codes
  MODIFY purpose ENUM('register','family_register','reset','change_email') NOT NULL DEFAULT 'register';
