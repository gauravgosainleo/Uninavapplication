<?php
require_once __DIR__ . '/../includes/helpers.php';
flash('msg', 'Password reset now works from the login screen. Select your house and request reset.');
redirect('auth/login.php');
