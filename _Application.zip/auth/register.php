<?php
require_once __DIR__ . '/../includes/helpers.php';
flash('msg', 'Please select your flat number on the login screen to register.');
redirect('auth/login.php');
