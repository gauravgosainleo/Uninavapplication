<?php
require_once __DIR__ . '/../includes/helpers.php';
flash('msg', 'Select your flat number, then use Reset password. Admin will approve it from Settings.');
redirect('auth/login.php');
