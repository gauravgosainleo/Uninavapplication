<?php
require_once __DIR__ . '/../includes/helpers.php';
ensure_family_schema();
if (is_logged_in()) redirect('dashboard.php');

$err = '';
$msg = flash('msg');
$preselectId = (int)($_GET['resident_id'] ?? 0);

function resident_by_id(int $id): ?array {
    if ($id <= 0) return null;
    $stmt = db()->prepare("SELECT u.*, p.tower AS parent_tower, p.house_number AS parent_house_number, p.owner_name AS parent_owner_name FROM users u LEFT JOIN users p ON p.id=u.parent_user_id WHERE u.id=? AND u.role='resident' LIMIT 1");
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

function set_login_session(array $u): void {
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$u['id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $err = 'Invalid session, please try again.';
    } else {
        $action = $_POST['action'] ?? 'resident_login';

        if ($action === 'admin_login') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['admin_password'] ?? '';
            $stmt = db()->prepare("SELECT * FROM users WHERE username=? AND role='admin' LIMIT 1");
            $stmt->execute([$username]);
            $u = $stmt->fetch();
            if ($u && !empty($u['password_hash']) && password_verify($password, $u['password_hash'])) {
                set_login_session($u);
                redirect('dashboard.php');
            } else {
                $err = 'Invalid admin credentials.';
            }
        }

        if ($action === 'resident_add_house') {
            $flat = $_POST['new_flat_number'] ?? '';
            [$tower, $house] = split_flat_number($flat);
            if ($tower === '' || $house === '') {
                $tower = normalize_tower($_POST['new_tower'] ?? '');
                $house = normalize_house_number($_POST['new_house_number'] ?? '');
            }
            $owner = trim($_POST['new_owner_name'] ?? '');

            if ($tower === '' || $house === '' || $owner === '') {
                $err = 'Flat number and owner name are required. Use a format like A-002.';
            } else {
                $dup = db()->prepare("SELECT id FROM users WHERE role='resident' AND tower=? AND house_number=? LIMIT 1");
                $dup->execute([$tower, $house]);
                $existingId = (int)($dup->fetchColumn() ?: 0);
                if ($existingId) {
                    $err = 'This flat number already exists. Please select it from the list.';
                    $preselectId = $existingId;
                } else {
                    $username = resident_username($tower, $house);
                    $base = $username;
                    $n = 2;
                    while (true) {
                        $check = db()->prepare('SELECT id FROM users WHERE username=? LIMIT 1');
                        $check->execute([$username]);
                        if (!$check->fetchColumn()) break;
                        $suffix = '-' . $n++;
                        $username = substr($base, 0, 100 - strlen($suffix)) . $suffix;
                    }
                    db()->prepare("INSERT INTO users (username,tower,house_number,owner_name,password_hash,role,email_verified,reset_requested) VALUES (?,?,?,?,NULL,'resident',0,0)")
                        ->execute([$username, $tower, $house, $owner]);
                    $newId = (int)db()->lastInsertId();
                    flash('msg', 'Flat added. Please create your password to register.');
                    redirect('auth/login.php?resident_id=' . $newId);
                }
            }
        }

        if (in_array($action, ['resident_login','resident_register','request_reset'], true)) {
            $rid = (int)($_POST['resident_id'] ?? 0);
            $preselectId = $rid;
            $u = resident_by_id($rid);
            if (!$u) {
                $err = 'Please choose a valid flat number or owner name.';
            } elseif ((int)($u['reset_requested'] ?? 0) === 1 && $action !== 'request_reset') {
                $err = 'Password reset request is pending with admin. Please try again after admin approval.';
            } elseif ($action === 'request_reset') {
                if (empty($u['password_hash'])) {
                    $err = 'This flat is not registered yet. Please create a password to register.';
                } else {
                    db()->prepare('UPDATE users SET reset_requested=1 WHERE id=?')->execute([$u['id']]);
                    flash('msg', 'Password reset request sent to admin. After approval, you can register again.');
                    redirect('auth/login.php?resident_id=' . (int)$u['id']);
                }
            } elseif ($action === 'resident_login') {
                $password = $_POST['password'] ?? '';
                if (empty($u['password_hash'])) {
                    $err = 'This flat is not registered yet. Please create a password.';
                } elseif (password_verify($password, $u['password_hash'])) {
                    set_login_session($u);
                    redirect('dashboard.php');
                } else {
                    $err = 'Invalid password.';
                }
            } elseif ($action === 'resident_register') {
                $pass = $_POST['password'] ?? '';
                $cpass = $_POST['confirm_password'] ?? '';
                if (!empty($u['password_hash'])) {
                    $err = 'This flat is already registered. Please enter the password to login.';
                } elseif (strlen($pass) < 6) {
                    $err = 'Password too short. Use at least 6 characters.';
                } elseif ($pass !== $cpass) {
                    $err = 'Passwords do not match.';
                } else {
                    db()->prepare('UPDATE users SET password_hash=?, email_verified=1, reset_requested=0 WHERE id=?')
                        ->execute([password_hash($pass, PASSWORD_DEFAULT), $u['id']]);
                    $u['password_hash'] = 'set';
                    set_login_session($u);
                    redirect('dashboard.php');
                }
            }
        }
    }
}

$residents = db()->query("SELECT u.id, COALESCE(NULLIF(u.tower,''), p.tower) AS tower, COALESCE(NULLIF(u.house_number,''), p.house_number) AS house_number, u.owner_name, u.parent_user_id, u.member_relation, p.owner_name AS parent_owner_name, CASE WHEN u.password_hash IS NOT NULL AND u.password_hash<>'' THEN 1 ELSE 0 END AS is_registered, u.reset_requested FROM users u LEFT JOIN users p ON p.id = u.parent_user_id WHERE u.role='resident' AND ((u.parent_user_id IS NULL AND u.tower IS NOT NULL AND u.tower<>'' AND u.house_number IS NOT NULL AND u.house_number<>'') OR (u.parent_user_id IS NOT NULL AND p.id IS NOT NULL AND p.tower IS NOT NULL AND p.tower<>'' AND p.house_number IS NOT NULL AND p.house_number<>'')) ORDER BY COALESCE(NULLIF(u.tower,''), p.tower), CAST(COALESCE(NULLIF(u.house_number,''), p.house_number) AS UNSIGNED), COALESCE(NULLIF(u.house_number,''), p.house_number), u.parent_user_id, u.owner_name")->fetchAll();
$residentOptions = array_map(function ($r) {
    return [
        'id' => (int)$r['id'],
        'tower' => (string)$r['tower'],
        'house_number' => (string)$r['house_number'],
        'flat_number' => resident_flat_label($r['tower'], $r['house_number']),
        'owner_name' => (string)$r['owner_name'],
        'parent_user_id' => (int)($r['parent_user_id'] ?? 0),
        'parent_owner_name' => (string)($r['parent_owner_name'] ?? ''),
        'member_relation' => (string)($r['member_relation'] ?? ''),
        'display_name' => !empty($r['parent_user_id'])
            ? (string)$r['owner_name'] . ' (Family of ' . (string)($r['parent_owner_name'] ?: 'Primary Resident') . ')'
            : (string)$r['owner_name'],
        'is_registered' => (int)$r['is_registered'],
        'reset_requested' => (int)($r['reset_requested'] ?? 0),
    ];
}, $residents);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body class="auth-body">
<div class="auth-wrap auth-wide">
  <div class="auth-card">
    <div class="brand">
      <div class="logo">UV</div>
      <h1>Resident Login</h1>
      <p class="muted">Search by flat number, resident name, or family member name to continue</p>
    </div>
    <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
    <?php if ($msg): ?><div class="alert ok"><?= e($msg) ?></div><?php endif; ?>

    <form method="post" class="form" id="resident-form">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <input type="hidden" name="action" id="resident-action" value="resident_login">
      <input type="hidden" name="resident_id" id="resident-id" value="">

      <div class="grid2">
        <div>
          <label>Tower / House Number</label>
          <input type="text" id="flat-input" list="flat-list" placeholder="e.g. A-002" autocomplete="off" spellcheck="false">
          <datalist id="flat-list"></datalist>
        </div>
        <div>
          <label>Resident / Family Member Name</label>
          <input type="text" id="name-input" list="name-list" placeholder="Start typing resident or family member name" autocomplete="off" spellcheck="false">
          <datalist id="name-list"></datalist>
        </div>
      </div>
      <div id="search-hint" class="small muted" style="margin-top:6px;min-height:1em;"></div>

      <div id="owner-card" class="resident-name hidden">
        <div class="small muted">Selected Login</div>
        <b id="owner-name"></b>
        <div id="resident-status" class="small muted"></div>
      </div>

      <div id="registered-panel" class="hidden">
        <label>Password</label>
        <input type="password" name="password" id="login-password" autocomplete="current-password" disabled>
        <div class="auth-actions">
          <button class="btn primary" type="submit" data-action="resident_login">Login</button>
          <button class="btn ghost" type="submit" data-action="request_reset" formnovalidate>Reset password</button>
        </div>
      </div>

      <div id="register-panel" class="hidden">
        <div class="alert ok">This flat is not registered yet. Create a password to register.</div>
        <div class="grid2">
          <div><label>Create Password</label><input type="password" name="password" id="new-password" autocomplete="new-password" disabled></div>
          <div><label>Confirm Password</label><input type="password" name="confirm_password" id="confirm-password" autocomplete="new-password" disabled></div>
        </div>
        <button class="btn primary" type="submit" data-action="resident_register">Register</button>
      </div>

      <div id="pending-panel" class="alert err hidden">
        Password reset is pending with admin. Once admin clicks reset in Settings, you can register again here.
      </div>
    </form>

    <button class="btn ghost full" type="button" onclick="document.getElementById('house-modal').classList.add('open')">House number not found click here</button>

    <div class="auth-divider"><span>Admin access</span></div>
    <details class="admin-details">
      <summary>Login as admin</summary>
      <form method="post" class="form admin-form">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="admin_login">
        <label>Username</label>
        <input type="text" name="username" autocomplete="username" required>
        <label>Password</label>
        <input type="password" name="admin_password" autocomplete="current-password" required>
        <button class="btn primary" type="submit">Login</button>
      </form>
    </details>
  </div>
</div>

<div class="modal" id="house-modal">
  <div class="modal-card">
    <div class="modal-head">
      <h3>Add Flat Number</h3>
      <button class="x" type="button" onclick="document.getElementById('house-modal').classList.remove('open')">×</button>
    </div>
    <div class="modal-body">
      <form method="post" class="form">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="resident_add_house">
        <label>Tower / House Number</label>
        <input type="text" name="new_flat_number" maxlength="40" placeholder="Example: A-002" required>
        <div class="small muted">Enter the combined flat number exactly like the list, e.g. A-002 or G-1205A.</div>
        <label>Owner Name</label>
        <input type="text" name="new_owner_name" maxlength="150" required>
        <button class="btn primary" type="submit">Add and continue</button>
      </form>
    </div>
  </div>
</div>

<script>
const residents = <?= json_encode($residentOptions, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT) ?>;
const preselectId = <?= (int)$preselectId ?>;

const flatInput = document.getElementById('flat-input');
const nameInput = document.getElementById('name-input');
const flatList = document.getElementById('flat-list');
const nameList = document.getElementById('name-list');
const residentId = document.getElementById('resident-id');
const searchHint = document.getElementById('search-hint');

const ownerCard = document.getElementById('owner-card');
const ownerName = document.getElementById('owner-name');
const statusText = document.getElementById('resident-status');
const registeredPanel = document.getElementById('registered-panel');
const registerPanel = document.getElementById('register-panel');
const pendingPanel = document.getElementById('pending-panel');
const actionInput = document.getElementById('resident-action');
const loginPassword = document.getElementById('login-password');
const newPassword = document.getElementById('new-password');
const confirmPassword = document.getElementById('confirm-password');

const NAME_SEP = ' \u2014 '; // " — "

function naturalSort(a, b) { return String(a).localeCompare(String(b), undefined, {numeric:true, sensitivity:'base'}); }
function clearPanel(panel) { panel.classList.add('hidden'); panel.querySelectorAll('input').forEach(i => { i.disabled = true; i.required = false; i.value = ''; }); }
function showPanel(panel) { panel.classList.remove('hidden'); panel.querySelectorAll('input').forEach(i => { i.disabled = false; if (i.type === 'password') i.required = true; }); }
function flatLabel(r) { return r.flat_number || ((r.tower ? r.tower + '-' : '') + r.house_number); }

function flatOptionValue(r) {
  const flat = flatLabel(r);
  const duplicateCount = residents.filter(x => flatLabel(x).toUpperCase() === flat.toUpperCase()).length;
  const nm = (r.display_name || r.owner_name || '').trim();
  return duplicateCount > 1 && nm ? flat + NAME_SEP + nm : flat;
}

function populateDatalists() {
  const byFlat = residents.slice().sort((a,b) => {
    const cmp = naturalSort(flatLabel(a), flatLabel(b));
    if (cmp !== 0) return cmp;
    if (!a.parent_user_id && b.parent_user_id) return -1;
    if (a.parent_user_id && !b.parent_user_id) return 1;
    return String(a.owner_name||'').localeCompare(String(b.owner_name||''), undefined, {sensitivity:'base'});
  });
  byFlat.forEach(r => {
    const opt = document.createElement('option');
    opt.value = flatOptionValue(r);
    opt.textContent = r.display_name || r.owner_name || '';
    flatList.appendChild(opt);
  });

  const byName = residents.slice().sort((a,b) => String(a.owner_name||'').localeCompare(String(b.owner_name||''), undefined, {sensitivity:'base'}));
  byName.forEach(r => {
    const nm = (r.display_name || r.owner_name || '').trim();
    if (!nm) return;
    const opt = document.createElement('option');
    opt.value = nm + NAME_SEP + flatLabel(r);
    nameList.appendChild(opt);
  });
}

function findByFlat(v) {
  const raw = String(v || '').trim();
  const needle = raw.toUpperCase();
  if (!needle) return [];

  const idx = raw.indexOf(NAME_SEP);
  if (idx !== -1) {
    const flat = raw.slice(0, idx).trim().toUpperCase();
    const name = raw.slice(idx + NAME_SEP.length).trim().toLowerCase();
    return residents.filter(r =>
      flatLabel(r).toUpperCase() === flat &&
      String(r.display_name || r.owner_name || '').trim().toLowerCase() === name
    );
  }

  const matches = residents.filter(r => flatLabel(r).toUpperCase() === needle);
  if (matches.length > 1) {
    const primary = matches.find(r => !r.parent_user_id);
    if (primary) return [primary];
  }
  return matches;
}

function findByName(v) {
  let s = String(v || '').trim();
  if (!s) return [];
  const idx = s.indexOf(NAME_SEP);
  if (idx !== -1) {
    const name = s.slice(0, idx).trim().toLowerCase();
    const flat = s.slice(idx + NAME_SEP.length).trim().toUpperCase();
    return residents.filter(r =>
      String(r.display_name || r.owner_name || '').trim().toLowerCase() === name &&
      flatLabel(r).toUpperCase() === flat
    );
  }
  const needle = s.toLowerCase();
  return residents.filter(r => String(r.display_name || r.owner_name || '').trim().toLowerCase() === needle || String(r.owner_name || '').trim().toLowerCase() === needle);
}

function clearSelection() {
  residentId.value = '';
  clearPanel(registeredPanel);
  clearPanel(registerPanel);
  pendingPanel.classList.add('hidden');
  ownerCard.classList.add('hidden');
}

function applySelected(r) {
  residentId.value = r.id;
  ownerName.textContent = r.display_name || r.owner_name || 'Name not available';
  ownerCard.classList.remove('hidden');
  clearPanel(registeredPanel);
  clearPanel(registerPanel);
  pendingPanel.classList.add('hidden');

  if (Number(r.reset_requested) === 1) {
    statusText.textContent = 'Reset request pending';
    pendingPanel.classList.remove('hidden');
    actionInput.value = 'resident_login';
  } else if (Number(r.is_registered) === 1) {
    statusText.textContent = 'Registered. Enter password to login.';
    actionInput.value = 'resident_login';
    showPanel(registeredPanel);
  } else {
    statusText.textContent = 'Not registered. Create a password.';
    actionInput.value = 'resident_register';
    showPanel(registerPanel);
  }
}

function onFlatInput() {
  const matches = findByFlat(flatInput.value);
  if (matches.length === 1) {
    const r = matches[0];
    flatInput.value = flatLabel(r);
    nameInput.value = r.display_name || r.owner_name || '';
    searchHint.textContent = '';
    applySelected(r);
  } else {
    if (flatInput.value.trim() === '') {
      nameInput.value = '';
      searchHint.textContent = '';
    } else {
      searchHint.textContent = 'No matching flat. Pick one from the list.';
    }
    clearSelection();
  }
}

function onNameInput() {
  const matches = findByName(nameInput.value);
  if (matches.length === 1) {
    const r = matches[0];
    flatInput.value = flatLabel(r);
    // If user picked a "Name — A-002" suggestion, clean the input back to just the name
    if (nameInput.value.indexOf(NAME_SEP) !== -1) nameInput.value = r.display_name || r.owner_name || '';
    searchHint.textContent = '';
    applySelected(r);
  } else if (matches.length > 1) {
    flatInput.value = '';
    const flats = Array.from(new Set(matches.map(m => flatLabel(m)))).join(', ');
    searchHint.textContent = 'Multiple flats for this name (' + flats + '). Pick the tower/house number to continue.';
    clearSelection();
  } else {
    flatInput.value = '';
    if (nameInput.value.trim() === '') {
      searchHint.textContent = '';
    } else {
      searchHint.textContent = 'No matching owner name. Pick one from the list.';
    }
    clearSelection();
  }
}

document.querySelectorAll('#resident-form button[data-action]').forEach(btn => {
  btn.addEventListener('click', e => {
    actionInput.value = btn.dataset.action;
    if (btn.dataset.action === 'request_reset') {
      [loginPassword, newPassword, confirmPassword].forEach(i => { i.required = false; });
      if (!confirm('Send password reset request to admin?')) e.preventDefault();
    }
  });
});

document.getElementById('resident-form').addEventListener('submit', function (e) {
  if (!residentId.value) {
    e.preventDefault();
    searchHint.textContent = 'Please select a flat by house number, resident name, or family member name.';
  }
});

flatInput.addEventListener('input', onFlatInput);
nameInput.addEventListener('input', onNameInput);

populateDatalists();

if (preselectId) {
  const r = residents.find(x => String(x.id) === String(preselectId));
  if (r) {
    flatInput.value = flatLabel(r);
    nameInput.value = r.display_name || r.owner_name || '';
    applySelected(r);
  }
}
</script>
</body>
</html>
