<?php
require_once __DIR__ . '/../config/db.php';

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function redirect($path) {
    header('Location: ' . APP_URL . '/' . ltrim($path, '/'));
    exit;
}

function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function require_login() {
    if (!is_logged_in()) redirect('auth/login.php');
}

function require_admin() {
    require_login();
    $u = current_user();
    if (!$u || $u['role'] !== 'admin') {
        http_response_code(403);
        die('Access denied. Admins only.');
    }
}

function is_admin(): bool {
    $u = current_user();
    return $u && $u['role'] === 'admin';
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['csrf'];
}

function csrf_check(): bool {
    $t = $_POST['csrf'] ?? $_GET['csrf'] ?? '';
    return hash_equals($_SESSION['csrf'] ?? '', $t);
}

function flash($key, $msg = null) {
    if ($msg === null) {
        $m = $_SESSION['flash'][$key] ?? null;
        unset($_SESSION['flash'][$key]);
        return $m;
    }
    $_SESSION['flash'][$key] = $msg;
}

function upload_file(array $file, string $subdir): ?string {
    if (empty($file['name']) || $file['error'] !== UPLOAD_ERR_OK) return null;
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png','gif','webp'];
    if (!in_array($ext, $allowed, true)) return null;
    $dir = UPLOAD_DIR . '/' . $subdir;
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    $dest = $dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $dest)) return null;
    return $subdir . '/' . $name;
}

function upload_url($rel) {
    return $rel ? UPLOAD_URL . '/' . $rel : '';
}

function send_mail(string $to, string $subject, string $html, array $extraHeaders = []): bool {
    $headers  = [];
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-Type: text/html; charset=UTF-8';
    $headers[] = 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . '>';
    $headers[] = 'Reply-To: ' . MAIL_FROM;
    foreach ($extraHeaders as $h) $headers[] = $h;
    return @mail($to, $subject, $html, implode("\r\n", $headers));
}

function months_ago($n = 12): array {
    $out = [];
    for ($i = 0; $i < $n; $i++) {
        $t = strtotime("-$i months");
        $out[] = date('Y-m', $t);
    }
    return $out;
}


function uv_column_exists(string $table, string $column): bool {
    $stmt = db()->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function uv_index_exists(string $table, string $index): bool {
    $stmt = db()->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?');
    $stmt->execute([$table, $index]);
    return (int)$stmt->fetchColumn() > 0;
}

function ensure_family_schema(): void {
    static $done = false;
    if ($done) return;
    $pdo = db();
    if (!uv_column_exists('users', 'parent_user_id')) {
        $pdo->exec('ALTER TABLE users ADD COLUMN parent_user_id INT NULL AFTER id');
    }
    if (!uv_column_exists('users', 'member_relation')) {
        $pdo->exec('ALTER TABLE users ADD COLUMN member_relation VARCHAR(60) NULL AFTER owner_name');
    }
    if (!uv_index_exists('users', 'idx_parent_user_id')) {
        $pdo->exec('ALTER TABLE users ADD INDEX idx_parent_user_id (parent_user_id)');
    }
    $done = true;
}

function effective_home_for_user(array $user): array {
    if (!empty($user['tower']) || !empty($user['house_number'])) {
        return ['tower' => $user['tower'] ?? '', 'house_number' => $user['house_number'] ?? ''];
    }
    if (!empty($user['parent_user_id'])) {
        ensure_family_schema();
        $stmt = db()->prepare('SELECT tower, house_number FROM users WHERE id=? LIMIT 1');
        $stmt->execute([(int)$user['parent_user_id']]);
        $parent = $stmt->fetch() ?: [];
        return ['tower' => $parent['tower'] ?? '', 'house_number' => $parent['house_number'] ?? ''];
    }
    return ['tower' => '', 'house_number' => ''];
}

function user_flat_label(array $user): string {
    $home = effective_home_for_user($user);
    return resident_flat_label($home['tower'] ?? '', $home['house_number'] ?? '');
}

function normalize_tower($tower): string {
    return strtoupper(trim(preg_replace('/\s+/', '', (string)$tower)));
}

function normalize_house_number($house): string {
    return strtoupper(trim(preg_replace('/\s+/', '', (string)$house)));
}

function resident_username($tower, $house): string {
    $tower = preg_replace('/[^A-Z0-9]+/', '-', normalize_tower($tower));
    $house = preg_replace('/[^A-Z0-9]+/', '-', normalize_house_number($house));
    $tower = trim($tower, '-');
    $house = trim($house, '-');
    return substr('RES-' . $tower . '-' . $house, 0, 100);
}

function normalize_flat_number($flat): string {
    $flat = strtoupper(trim((string)$flat));
    $flat = str_replace(['–', '—', '_', '/'], '-', $flat);
    $flat = preg_replace('/\s*-\s*/', '-', $flat);
    $flat = preg_replace('/\s+/', '', $flat);
    return trim($flat, '-');
}

function split_flat_number($flat): array {
    $flat = normalize_flat_number($flat);
    if ($flat === '') return ['', ''];
    if (strpos($flat, '-') !== false) {
        [$tower, $house] = array_pad(explode('-', $flat, 2), 2, '');
    } elseif (preg_match('/^([A-Z]+)([0-9].*)$/', $flat, $m)) {
        $tower = $m[1];
        $house = $m[2];
    } else {
        return ['', normalize_house_number($flat)];
    }
    return [normalize_tower($tower), normalize_house_number($house)];
}

function resident_flat_label($tower, $house): string {
    $tower = normalize_tower($tower);
    $house = normalize_house_number($house);
    return $tower !== '' && $house !== '' ? $tower . '-' . $house : trim($tower . $house);
}

