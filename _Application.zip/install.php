<?php
// =====================================================================
// Uni-Vishwas Management - Installer
// Run once in browser:  /Uninav/Application/install.php
// =====================================================================
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/helpers.php';

$log = [];
$ok  = true;

function run_step(&$log, &$ok, $name, $fn) {
    try { $fn(); $log[] = "[OK] $name"; }
    catch (Throwable $e) { $ok = false; $log[] = "[FAIL] $name - " . $e->getMessage(); }
}

function column_exists(string $table, string $column): bool {
    $stmt = db()->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function index_exists(string $table, string $index): bool {
    $stmt = db()->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?');
    $stmt->execute([$table, $index]);
    return (int)$stmt->fetchColumn() > 0;
}

// 1. Run schema
run_step($log, $ok, 'Apply schema.sql', function () {
    $sql = file_get_contents(__DIR__ . '/sql/schema.sql');
    $pdo = db();
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) {
        if ($stmt !== '') $pdo->exec($stmt);
    }
});

// 2. Upgrade existing users table for house-based login
run_step($log, $ok, 'Upgrade resident login columns', function () {
    $pdo = db();
    if (column_exists('users', 'tower')) {
        $pdo->exec('ALTER TABLE users MODIFY tower VARCHAR(20) NULL');
    }
    if (column_exists('users', 'password_hash')) {
        $pdo->exec('ALTER TABLE users MODIFY password_hash VARCHAR(255) NULL');
    }
    if (!column_exists('users', 'reset_requested')) {
        $pdo->exec('ALTER TABLE users ADD COLUMN reset_requested TINYINT(1) NOT NULL DEFAULT 0 AFTER email_verified');
    }
    if (!column_exists("users", "parent_user_id")) {
        $pdo->exec("ALTER TABLE users ADD COLUMN parent_user_id INT NULL AFTER id");
    }
    if (!column_exists("users", "member_relation")) {
        $pdo->exec("ALTER TABLE users ADD COLUMN member_relation VARCHAR(60) NULL AFTER owner_name");
    }
    if (!index_exists('users', 'idx_resident_lookup')) {
        $pdo->exec('ALTER TABLE users ADD INDEX idx_resident_lookup (role, tower, house_number)');
    }
    if (!index_exists('users', 'idx_reset_requested')) {
        $pdo->exec('ALTER TABLE users ADD INDEX idx_reset_requested (reset_requested)');
    }
    if (!index_exists("users", "idx_parent_user_id")) {
        $pdo->exec("ALTER TABLE users ADD INDEX idx_parent_user_id (parent_user_id)");
    }
    if (!index_exists('users', 'uniq_resident_house')) {
        try { $pdo->exec('ALTER TABLE users ADD UNIQUE KEY uniq_resident_house (tower, house_number)'); }
        catch (Throwable $e) { /* Existing duplicates can prevent this optional safeguard. */ }
    }
});

// 3. Upgrade third-party vendor/helper tables
run_step($log, $ok, 'Upgrade third-party vendor helper tables', function () {
    $pdo = db();
    if (column_exists('vendors', 'category')) {
        $pdo->exec("ALTER TABLE vendors MODIFY category ENUM('maid','press','car_cleaner','security','housekeeping','other') NOT NULL");
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_house_helpers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        vendor_id INT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_user_vendor (user_id, vendor_id),
        INDEX (user_id),
        INDEX (vendor_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
});

// 4. Seed resident flats from Excel-generated SQL
run_step($log, $ok, 'Seed resident flats', function () {
    $file = __DIR__ . '/sql/residents_seed.sql';
    if (is_file($file)) db()->exec(file_get_contents($file));
});

// 5. Seed admin user
run_step($log, $ok, 'Seed admin user', function () {
    $stmt = db()->prepare('SELECT id FROM users WHERE username = ?');
    $stmt->execute([ADMIN_USERNAME]);
    if (!$stmt->fetch()) {
        $hash = password_hash(ADMIN_PASSWORD, PASSWORD_DEFAULT);
        db()->prepare('INSERT INTO users (username, owner_name, password_hash, role, email_verified) VALUES (?,?,?,?,1)')
            ->execute([ADMIN_USERNAME, 'Society Administrator', $hash, 'admin']);
    }
});

// 6. Remove any legacy guest user (guest login is no longer supported)
run_step($log, $ok, 'Remove legacy guest user', function () {
    db()->prepare("DELETE FROM users WHERE role = 'guest'")->execute();
});

// 7. Ensure upload dirs
run_step($log, $ok, 'Create upload directories', function () {
    foreach (['complaints','notices','vendors','ads','profiles','polls','events'] as $d) {
        $p = UPLOAD_DIR . '/' . $d;
        if (!is_dir($p)) mkdir($p, 0775, true);
    }
});
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Install Uni-Vishwas</title>
<link rel="stylesheet" href="assets/css/style.css"></head>
<body style="padding:40px;font-family:system-ui;">
<h1>Uni-Vishwas - Installer</h1>
<ul>
<?php foreach ($log as $l): ?>
<li><?= e($l) ?></li>
<?php endforeach; ?>
</ul>
<?php if ($ok): ?>
    <p style="color:green;font-weight:bold;">Install complete.
       <a href="<?= APP_URL ?>/auth/login.php">Go to Login &rarr;</a></p>
    <p style="color:#900;"><strong>Security:</strong> delete <code>install.php</code> after setup.</p>
<?php else: ?>
    <p style="color:red;font-weight:bold;">Install encountered errors, see above.</p>
<?php endif; ?>
</body></html>
