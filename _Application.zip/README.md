# Uni-Vishwas - Residential Society Management

A complete, self-contained PHP/MySQL application for managing a residential
society. Deployable to Hostinger shared hosting over FTP.

- **Target URL:** `http://learninganddevelopment.net/Uninav/Application/`
- **Stack:** PHP 7.4+ / MySQL / vanilla JS / Chart.js via CDN

## Features

- House-based resident login using Tower + House dropdown, seeded from `sql/residents_seed.sql`
- Login (Resident / Admin)
- Password reset request flow: resident requests reset, admin approves reset in Settings, resident registers again
- User profile (photo upload, change password, change email via OTP)
- **Event Calendar** (month view + popup details)
- **Society Notices** (search + filter, image attachments)
- **Complaints** with status workflow + email notifications +
  admin dashboard (tiles, charts, comments, status updates)
- **Finance & Expenses** (monthly tiles, expense details)
- **Third-party Vendors** across 5 categories with own-maid detection
  (by house) + one-click complaint-from-panel
- **Advertisements** (user posts, admin moderation, restrict users)
- **Polls** (MCQ, vote tracking, PDF export, email to residents)
- **Admin Settings** panel consolidating all management

## Credentials

| Role     | Username   | Password   |
| -------- | ---------- | ---------- |
| Admin    | `Uniadmin` | `99114212` |
| Resident | Search by house number or owner name | Create password on first login |

## Installation

1. Upload the entire `Uninav/Application/` folder to your FTP root (so URLs
   resolve to `http://learninganddevelopment.net/Uninav/Application/...`).
2. Make sure the `uploads/` folder is writable (CHMOD 755 or 775).
3. In your browser open **once** after upload or after applying this update:
   ```
   http://learninganddevelopment.net/Uninav/Application/install.php
   ```
   This creates/updates database tables, seeds the admin account, removes any legacy guest account, and loads resident Tower/House/Owner data from the Excel-generated SQL file.
4. **Delete `install.php`** after a successful run.
5. Log in: `/auth/login.php`.

## Database

- Host: `localhost`
- DB:   `u694536902_uninav`
- User: `u694536902_uninavGaurav`
- Pass: stored in `config/config.php`

The SQL schema is in `sql/schema.sql`.

## Complaint Routing

All new complaints are emailed to **gauravgosain@ymail.com** using PHP
`mail()`. Status updates also email the reporting resident.

## Notes

- Session cookies named `UNINAVSESS`.
- CSRF tokens are enforced on every POST.
- Uploads live under `uploads/{complaints,notices,vendors,ads,profiles,events}`.
- PHP execution in `uploads/` is blocked by `.htaccess`.


## Resident Login Update

- Resident data from `AOA_Voters_Uninav_Heights-2(1).xlsx` has been converted into `sql/residents_seed.sql`.
- Excel Column B is stored as `owner_name`; Column C is the combined flat number, split internally into `tower` and `house_number`.
- Residents search on `/auth/login.php` either by **Tower / House Number** (e.g. `A-002`) or by **Owner Name** — selecting one auto-populates the other.
- If an owner name matches more than one flat, the page asks the user to pick the tower/house number to disambiguate.
- After a flat is matched, the owner name is shown. Registered residents enter only their password. Unregistered residents create and confirm a password.
- If a house is missing, residents can add the combined Tower / House Number and Owner Name from the login popup.
- Password reset requests appear in **Settings > Users** for admin approval.
- Guest login has been removed; only Admin and Resident roles remain.
