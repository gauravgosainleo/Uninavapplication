<?php
require_once __DIR__ . '/../includes/layout.php';
$U = current_user();

$cats = [
    'maid'         => 'Maid',
    'press'        => 'Press',
    'car_cleaner'  => 'Car Cleaner',
    'security'     => 'Security',
    'housekeeping' => 'House Keeping',
    'other'        => 'Other Helper',
];
$cat = $_GET['cat'] ?? 'maid';
if (!isset($cats[$cat])) $cat = 'maid';

$err = $msg = '';

// Upgrade-safe helper mapping for resident-selected house helpers.
db()->exec("CREATE TABLE IF NOT EXISTS user_house_helpers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    vendor_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_vendor (user_id, vendor_id),
    INDEX (user_id),
    INDEX (vendor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Resident marks/unmarks helpers from the vendor list.
if ($_SERVER['REQUEST_METHOD']==='POST' && csrf_check() && ($_POST['action'] ?? '')==='toggle_house_helper' && $U['role']==='resident') {
    $vid = (int)($_POST['vendor_id'] ?? 0);
    $mode = $_POST['mode'] ?? 'add';

    $stmt = db()->prepare('SELECT id, name FROM vendors WHERE id=?');
    $stmt->execute([$vid]);
    $v = $stmt->fetch();

    if (!$v) {
        $err = 'Invalid helper selected.';
    } elseif ($mode === 'remove') {
        db()->prepare('DELETE FROM user_house_helpers WHERE user_id=? AND vendor_id=?')->execute([$U['id'], $vid]);
        $msg = $v['name'] . ' removed from Your House Helpers.';
    } else {
        db()->prepare('INSERT IGNORE INTO user_house_helpers (user_id, vendor_id) VALUES (?,?)')->execute([$U['id'], $vid]);
        $msg = $v['name'] . ' added to Your House Helpers.';
    }
}

// Raise complaint from vendor panel (residents only). It follows the same admin/status flow as normal complaints.
if ($_SERVER['REQUEST_METHOD']==='POST' && csrf_check() && ($_POST['action'] ?? '')==='vendor_complaint' && $U['role']==='resident') {
    $vid = (int)$_POST['vendor_id'];
    $desc = trim($_POST['description'] ?? '');
    if ($desc==='') $err = 'Description required.';
    else {
        $stmt = db()->prepare('SELECT name, category FROM vendors WHERE id=?');
        $stmt->execute([$vid]);
        $v = $stmt->fetch();
        if (!$v) $err='Invalid helper.';
        else {
            db()->prepare('INSERT IGNORE INTO user_house_helpers (user_id, vendor_id) VALUES (?,?)')->execute([$U['id'], $vid]);

            $label = $cats[$v['category']] ?? 'House Helper';
            $subject = "House Helper Complaint - ".$label." - ".$v['name'];
            $img = upload_file($_FILES['image'] ?? [], 'complaints');
            db()->prepare('INSERT INTO complaints (user_id,subject,description,image,related_type,related_id,status) VALUES (?,?,?,?,?,?,?)')
                ->execute([$U['id'],$subject,$desc,$img,'vendor',$vid,'Complaint Raised']);
            $cid = db()->lastInsertId();

            $link = APP_URL . '/modules/complaints.php?id=' . $cid;
            send_mail(COMPLAINTS_INBOX, "[House Helper Complaint #$cid] ".$subject,
                "<p>From <b>".e($U['owner_name'])."</b> (".e($U['tower']).'-'.e($U['house_number']).")</p>
                 <p><b>Helper:</b> ".e($v['name'])." (".e($label).")</p>
                 <p><b>Description:</b><br>".nl2br(e($desc))."</p>
                 <p><a href='$link'>Open in portal</a></p>");
            if (!empty($U['email'])) {
                send_mail($U['email'], "House helper complaint #$cid received",
                    "<p>Your complaint has been logged and sent to admin. You will be notified when the status changes.</p>");
            }
            $msg = 'Complaint raised for this house helper and reported to admin.';
        }
    }
}

// Current category rows
$all = db()->prepare('SELECT * FROM vendors WHERE category=? ORDER BY name');
$all->execute([$cat]);
$rows = $all->fetchAll();

// All selected house helpers for the logged-in resident
$ownRows = [];
$ownIds = [];
$helperComplaints = [];
if ($U['role']==='resident') {
    $ownStmt = db()->prepare('SELECT v.* FROM vendors v JOIN user_house_helpers h ON h.vendor_id=v.id WHERE h.user_id=? ORDER BY v.category, v.name');
    $ownStmt->execute([$U['id']]);
    $ownRows = $ownStmt->fetchAll();
    $ownIds = array_map('intval', array_column($ownRows, 'id'));

    $hc = db()->prepare('SELECT c.*, v.name AS vendor_name, v.category AS vendor_category
                         FROM complaints c
                         LEFT JOIN vendors v ON v.id=c.related_id AND c.related_type=\'vendor\'
                         WHERE c.user_id=? AND c.related_type=\'vendor\'
                         ORDER BY c.id DESC');
    $hc->execute([$U['id']]);
    $helperComplaints = $hc->fetchAll();
}

// Load house mapping for displayed vendors
$displayIds = array_values(array_unique(array_merge(array_column($rows, 'id'), array_column($ownRows, 'id'))));
$houseMap = [];
if ($displayIds) {
    $in = implode(',', array_fill(0, count($displayIds), '?'));
    $hs = db()->prepare("SELECT vendor_id, tower, house_number FROM vendor_houses WHERE vendor_id IN ($in)");
    $hs->execute($displayIds);
    foreach ($hs->fetchAll() as $h) $houseMap[$h['vendor_id']][] = $h['tower'].'-'.$h['house_number'];
}

layout_shell_start('Third-party Vendors','vendors');
?>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
<?php if ($msg): ?><div class="alert ok"><?= e($msg) ?></div><?php endif; ?>

<?php if ($U['role']==='resident'): ?>
  <section class="panel helper-summary">
    <h3>Your House Helpers</h3>
    <p class="muted small">Mark helpers from the list below to keep them here. Complaints raised for house helpers are sent to admin and status updates appear here and in Complaints.</p>
    <?php if (!$ownRows): ?>
      <div class="empty compact"><i class="fa fa-user-check"></i><p>No house helpers selected yet.</p></div>
    <?php else: ?>
      <div class="grid-cards">
        <?php foreach ($ownRows as $v): ?>
          <?= render_vendor_card($v, $houseMap[$v['id']] ?? [], true, $U, true) ?>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  <section class="panel complaints-mini">
    <h3>Your House Helper Complaints</h3>
    <?php if (!$helperComplaints): ?>
      <p class="muted">No house helper complaints raised yet.</p>
    <?php else: ?>
      <table class="tbl">
        <thead><tr><th>#</th><th>Helper</th><th>Issue</th><th>Status</th><th>Created</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($helperComplaints as $c): ?>
          <tr>
            <td>#<?= $c['id'] ?></td>
            <td><?= e($c['vendor_name'] ?: 'House Helper') ?></td>
            <td><?= e($c['subject']) ?></td>
            <td><span class="pill <?= strtolower(str_replace(' ','-',$c['status'])) ?>"><?= e($c['status']) ?></span></td>
            <td class="muted small"><?= e(date('d M Y', strtotime($c['created_at']))) ?></td>
            <td><a class="btn ghost" href="complaints.php?id=<?= $c['id'] ?>">Open</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </section>
<?php endif; ?>

<div class="tabs">
  <?php foreach ($cats as $k=>$label): ?>
    <a href="?cat=<?= $k ?>" class="<?= $cat===$k?'active':'' ?>"><?= e($label) ?></a>
  <?php endforeach; ?>
</div>

<h3>All <?= e($cats[$cat]) ?></h3>
<?php if (!$rows): ?><div class="empty"><i class="fa fa-people-carry-box"></i><p>No entries yet.</p></div><?php endif; ?>
<div class="grid-cards">
  <?php foreach ($rows as $v): ?>
    <?= render_vendor_card($v, $houseMap[$v['id']] ?? [], in_array((int)$v['id'],$ownIds,true), $U, false) ?>
  <?php endforeach; ?>
</div>

<?php if (is_admin()): ?>
  <p class="muted">Admins: manage vendors under <a href="settings.php#vendors">Settings → 3rd Party Vendor</a>.</p>
<?php endif; ?>

<?php
function render_vendor_card($v, $houses, $isOwn, $U, $inOwnSection=false) {
    $modalId = 'vc-' . (int)$v['id'] . ($inOwnSection ? '-own' : '-all');
    ob_start(); ?>
    <div class="vendor-card <?= $isOwn?'own':'' ?>">
      <div class="v-head">
        <?php if ($v['photo']): ?>
          <img src="<?= e(upload_url($v['photo'])) ?>" class="avatar">
        <?php else: ?>
          <div class="avatar-initials"><?= e(strtoupper(substr($v['name'],0,1))) ?></div>
        <?php endif; ?>
        <div>
          <b><?= e($v['name']) ?></b>
          <div class="muted small">
            <?= $v['police_verified'] ? '<span class="pill done"><i class="fa fa-shield"></i> Verified</span>' : '<span class="pill ignored">Unverified</span>' ?>
            <span class="pill <?= $v['status']==='Available'?'done':'ignored' ?>"><?= e($v['status']) ?></span>
            <?php if ($isOwn): ?><span class="pill helper-pill"><i class="fa fa-check"></i> Your helper</span><?php endif; ?>
          </div>
        </div>
      </div>
      <?php if ($v['contact_number']): ?><div class="muted small"><i class="fa fa-phone"></i> <?= e($v['contact_number']) ?></div><?php endif; ?>
      <?php if ($houses): ?><div class="muted small"><i class="fa fa-house"></i> Assigned houses: <?= e(implode(', ', $houses)) ?></div><?php endif; ?>
      <?php if ($v['notes']): ?><div class="muted small"><?= e($v['notes']) ?></div><?php endif; ?>

      <?php if ($U['role']==='resident'): ?>
        <div class="vendor-actions">
          <form method="post">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="toggle_house_helper">
            <input type="hidden" name="vendor_id" value="<?= (int)$v['id'] ?>">
            <input type="hidden" name="mode" value="<?= $isOwn ? 'remove' : 'add' ?>">
            <button class="btn <?= $isOwn ? 'ghost' : 'primary' ?>">
              <i class="fa <?= $isOwn ? 'fa-xmark' : 'fa-check' ?>"></i>
              <?= $isOwn ? 'Remove from my helpers' : 'Mark as my helper' ?>
            </button>
          </form>

          <button type="button" class="btn ghost" onclick="document.getElementById('<?= $modalId ?>').classList.toggle('open')">
            <i class="fa fa-circle-exclamation"></i> Raise Complaint
          </button>
        </div>

        <div class="modal" id="<?= $modalId ?>">
          <div class="modal-card">
            <div class="modal-head"><h3>Complaint: <?= e($v['name']) ?></h3>
              <button class="x" onclick="document.getElementById('<?= $modalId ?>').classList.remove('open')">×</button></div>
            <div class="modal-body">
              <form method="post" enctype="multipart/form-data" class="form">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="vendor_complaint">
                <input type="hidden" name="vendor_id" value="<?= (int)$v['id'] ?>">
                <label>Describe the issue</label>
                <textarea name="description" rows="3" required></textarea>
                <label>Attach image (optional)</label>
                <input type="file" name="image" accept="image/*">
                <button class="btn primary">Submit to Admin</button>
              </form>
            </div>
          </div>
        </div>
      <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
layout_shell_end(); ?>
