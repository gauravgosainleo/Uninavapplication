<?php
require_once __DIR__ . '/../includes/layout.php';

$q    = trim($_GET['q'] ?? '');
$date = $_GET['date'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

$where = ' WHERE 1=1';
$args = [];
if ($q   !== '') { $where .= ' AND (title LIKE ? OR body LIKE ?)'; $args[]="%$q%"; $args[]="%$q%"; }
if ($date!== '') { $where .= ' AND posted_on = ?'; $args[] = $date; }

$countStmt = db()->prepare('SELECT COUNT(*) FROM notices'.$where);
$countStmt->execute($args);
$totalRows = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($totalRows / $perPage));
if ($page > $totalPages) { $page = $totalPages; $offset = ($page - 1) * $perPage; }

$sql = 'SELECT * FROM notices'.$where.' ORDER BY posted_on DESC, id DESC LIMIT '.$perPage.' OFFSET '.$offset;
$stmt = db()->prepare($sql); $stmt->execute($args);
$rows = $stmt->fetchAll();

$queryBase = $_GET;
unset($queryBase['page']);
$baseQs = http_build_query($queryBase);
$pageUrl = function($p) use ($baseQs) { return 'notices.php?'.($baseQs ? $baseQs.'&' : '').'page='.(int)$p; };

layout_shell_start('Society Notices','notices');
?>
<form method="get" class="filterbar">
  <input type="search" name="q" placeholder="Search notices…" value="<?= e($q) ?>">
  <input type="date" name="date" value="<?= e($date) ?>">
  <button class="btn primary"><i class="fa fa-filter"></i> Filter</button>
  <?php if ($q||$date): ?><a class="btn ghost" href="notices.php">Clear</a><?php endif; ?>
</form>

<?php if (!$rows): ?>
  <div class="empty"><i class="fa fa-bullhorn"></i><p>No notices yet.</p></div>
<?php endif; ?>

<div class="notice-list">
<?php foreach ($rows as $idx => $n): ?>
  <details class="notice-tile">
    <summary>
      <span class="notice-title-wrap">
        <strong><?= e($n['title']) ?></strong>
        <span class="muted small"><?= e(date('d M Y', strtotime($n['posted_on']))) ?></span>
      </span>
      <i class="fa fa-chevron-down notice-chevron"></i>
    </summary>
    <div class="notice-full">
      <?php if ($n['image']): ?><img src="<?= e(upload_url($n['image'])) ?>" alt="<?= e($n['title']) ?>"><?php endif; ?>
      <p><?= nl2br(e($n['body'])) ?></p>
    </div>
  </details>
<?php endforeach; ?>
</div>

<?php if ($totalRows > $perPage): ?>
  <div class="pager">
    <?php if ($page > 1): ?><a class="btn ghost" href="<?= e($pageUrl($page-1)) ?>"><i class="fa fa-arrow-left"></i> Previous</a><?php endif; ?>
    <span class="muted small">Page <?= e($page) ?> of <?= e($totalPages) ?> · showing top <?= e($perPage) ?> per page</span>
    <?php if ($page < $totalPages): ?><a class="btn ghost" href="<?= e($pageUrl($page+1)) ?>">Next <i class="fa fa-arrow-right"></i></a><?php endif; ?>
  </div>
<?php elseif ($totalRows): ?>
  <p class="muted small">Showing <?= e($totalRows) ?> notice<?= $totalRows===1?'':'s' ?>.</p>
<?php endif; ?>
<?php layout_shell_end(); ?>
