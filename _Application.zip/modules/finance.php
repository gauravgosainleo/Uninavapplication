<?php
require_once __DIR__ . '/../includes/layout.php';

// Upgrade-safe income table for existing installations.
db()->exec("CREATE TABLE IF NOT EXISTS finance_incomes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    month_year VARCHAR(7) NOT NULL,
    income_date DATE NOT NULL,
    description VARCHAR(250) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (month_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$month = $_GET['m'] ?? date('Y-m');
$stmt = db()->prepare('SELECT * FROM finance_months WHERE month_year=?');
$stmt->execute([$month]);
$fm = $stmt->fetch();

$inc = db()->prepare('SELECT COALESCE(SUM(amount),0) FROM finance_incomes WHERE month_year=?');
$inc->execute([$month]);
$totalIncome = (float)$inc->fetchColumn();

$exp = db()->prepare('SELECT COALESCE(SUM(amount),0) FROM finance_expenses WHERE month_year=?');
$exp->execute([$month]);
$totalExp = (float)$exp->fetchColumn();

$opening = (float)($fm['opening_balance'] ?? 0);
$balance = $opening + $totalIncome - $totalExp;

$incList = db()->prepare('SELECT * FROM finance_incomes WHERE month_year=? ORDER BY income_date DESC, id DESC');
$incList->execute([$month]);
$incomes = $incList->fetchAll();

$expList = db()->prepare('SELECT * FROM finance_expenses WHERE month_year=? ORDER BY expense_date DESC, id DESC');
$expList->execute([$month]);
$expenses = $expList->fetchAll();

$financeRows = [];
foreach ($incomes as $x) { $financeRows[] = ['type'=>'income','id'=>$x['id'],'date'=>$x['income_date'],'description'=>$x['description'],'income'=>(float)$x['amount'],'expense'=>0]; }
foreach ($expenses as $x) { $financeRows[] = ['type'=>'expense','id'=>$x['id'],'date'=>$x['expense_date'],'description'=>$x['description'],'income'=>0,'expense'=>(float)$x['amount']]; }
usort($financeRows, function($a,$b){ return strcmp($b['date'].'-'.$b['id'], $a['date'].'-'.$a['id']); });

$showAll = !empty($_GET['all']);
$showIncomes = !empty($_GET['incomes']);

layout_shell_start('Society Finance & Expenses','finance');
?>
<form method="get" class="filterbar">
  <label>Month</label>
  <input type="month" name="m" value="<?= e($month) ?>">
  <button class="btn primary">View</button>
</form>

<div class="tiles">
  <div class="tile raised"><div>Opening Balance</div><div class="big">₹<?= number_format($opening,2) ?></div></div>
  <div class="tile progress"><div>Monthly Income</div><div class="big">₹<?= number_format($totalIncome,2) ?></div></div>
  <div class="tile ignored"><div>Monthly Expenses</div><div class="big">₹<?= number_format($totalExp,2) ?></div></div>
  <div class="tile done"><div>Monthly Balance</div><div class="big">₹<?= number_format($balance,2) ?></div></div>
</div>

<h3>Income & Expenses for <?= e(date('F Y', strtotime($month.'-01'))) ?></h3>
<table class="tbl finance-ledger">
  <thead><tr><th>Date</th><th>Description</th><th>Expenses</th><th>Income</th></tr></thead>
  <tbody>
  <?php if (!$financeRows): ?>
    <tr><td colspan="4" class="muted">No income or expense entries recorded for this month.</td></tr>
  <?php endif; ?>
  <?php foreach ($financeRows as $x): ?>
    <tr>
      <td><?= e(date('d M Y', strtotime($x['date']))) ?></td>
      <td><?= e($x['description']) ?></td>
      <td><?= $x['expense'] > 0 ? '₹'.number_format($x['expense'],2) : '-' ?></td>
      <td><?= $x['income'] > 0 ? '₹'.number_format($x['income'],2) : '-' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>

<?php if (is_admin()): ?>
  <p class="muted">Admins: manage months, incomes and expenses under <a href="settings.php#finance">Settings → Finance</a>.</p>
<?php endif; ?>

<?php layout_shell_end(); ?>
