<?php
require_once __DIR__ . '/../includes/layout.php';
$U = current_user();

$departments = ['Maintainance','Security','Gym','Park and Horticulture','House Keeping','Fire','Electricity','Water'];

// Upgrade-safe table creation for already-installed portals.
db()->exec("CREATE TABLE IF NOT EXISTS society_spocs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    department ENUM('Maintainance','Security','Gym','Park and Horticulture','House Keeping','Fire','Electricity','Water') NOT NULL,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NULL,
    phone VARCHAR(30) NULL,
    photo VARCHAR(255) NULL,
    notes VARCHAR(250) NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (department)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$rows = db()->query("SELECT * FROM society_spocs ORDER BY FIELD(department, 'Maintainance','Security','Gym','Park and Horticulture','House Keeping','Fire','Electricity','Water'), name")->fetchAll();
$byDept = [];
foreach ($departments as $d) $byDept[$d] = [];
foreach ($rows as $r) $byDept[$r['department']][] = $r;

layout_shell_start('Society SPOCs','spocs');
?>

<section class="panel spoc-page">
  <div class="section-head">
    <div>
      <h3>Society SPOCs</h3>
      <p class="muted small">Department contacts configured by admin. Message and escalation options are placeholders for now.</p>
    </div>
  </div>
</section>

<?php foreach ($departments as $dept): ?>
  <section class="panel spoc-dept">
    <h3><?= e($dept) ?></h3>
    <?php if (empty($byDept[$dept])): ?>
      <div class="empty compact"><i class="fa fa-address-book"></i><p>No SPOC configured yet.</p></div>
    <?php else: ?>
      <div class="grid-cards spoc-grid">
        <?php foreach ($byDept[$dept] as $s): ?>
          <div class="vendor-card spoc-card">
            <div class="v-head">
              <?php if ($s['photo']): ?>
                <img src="<?= e(upload_url($s['photo'])) ?>" class="avatar spoc-avatar" alt="">
              <?php else: ?>
                <div class="avatar-initials spoc-avatar"><?= e(strtoupper(substr($s['name'],0,1))) ?></div>
              <?php endif; ?>
              <div>
                <b><?= e($s['name']) ?></b>
                <div class="muted small"><span class="pill helper-pill"><?= e($dept) ?></span></div>
              </div>
            </div>
            <?php if ($s['email']): ?><div class="muted small"><i class="fa fa-envelope"></i> <?= e($s['email']) ?></div><?php endif; ?>
            <?php if ($s['phone']): ?><div class="muted small"><i class="fa fa-phone"></i> <?= e($s['phone']) ?></div><?php endif; ?>
            <?php if ($s['notes']): ?><div class="muted small"><i class="fa fa-circle-info"></i> <?= e($s['notes']) ?></div><?php endif; ?>
            <div class="vendor-actions spoc-actions">
              <button type="button" class="btn ghost" onclick="alert('Coming soon')"><i class="fa fa-message"></i> Send Message - Coming soon</button>
              <button type="button" class="btn ghost" onclick="alert('Coming soon')"><i class="fa fa-arrow-up-right-from-square"></i> Escalation - Coming soon</button>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
<?php endforeach; ?>

<?php if (is_admin()): ?>
  <p class="muted">Admins: manage Society SPOCs under <a href="settings.php#spocs">Settings → Society SPOCs</a>.</p>
<?php endif; ?>

<?php layout_shell_end(); ?>
