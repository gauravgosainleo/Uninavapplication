<?php
require_once __DIR__ . '/../includes/layout.php';
ensure_family_schema();

$U = current_user();
$err = $msg = '';
$isPrimaryResident = $U && $U['role'] === 'resident' && empty($U['parent_user_id']) && !empty($U['password_hash']);

function family_username(int $parentId, string $name): string {
    $slug = strtoupper(trim(preg_replace('/[^A-Za-z0-9]+/', '-', $name), '-'));
    if ($slug === '') $slug = 'MEMBER';
    $base = substr('FAM-' . $parentId . '-' . $slug, 0, 90);
    $username = $base;
    $n = 2;
    while (true) {
        $stmt = db()->prepare('SELECT id FROM users WHERE username=? LIMIT 1');
        $stmt->execute([$username]);
        if (!$stmt->fetchColumn()) return $username;
        $suffix = '-' . $n++;
        $username = substr($base, 0, 100 - strlen($suffix)) . $suffix;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $err = 'Invalid session, please try again.';
    } elseif (!$isPrimaryResident) {
        $err = 'Only a registered primary resident can manage family member logins.';
    } else {
        $action = $_POST['action'] ?? '';
        if ($action === 'add') {
            $name = trim($_POST['member_name'] ?? '');
            $relation = trim($_POST['member_relation'] ?? '');
            $pass = $_POST['password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';

            if ($name === '') {
                $err = 'Family member name is required.';
            } elseif (strlen($pass) < 6) {
                $err = 'Password too short. Use at least 6 characters.';
            } elseif ($pass !== $confirm) {
                $err = 'Passwords do not match.';
            } else {
                $username = family_username((int)$U['id'], $name);
                db()->prepare("INSERT INTO users (parent_user_id, username, owner_name, member_relation, password_hash, role, email_verified, reset_requested) VALUES (?,?,?,?,?,'resident',1,0)")
                    ->execute([(int)$U['id'], $username, $name, $relation ?: null, password_hash($pass, PASSWORD_DEFAULT)]);
                $msg = 'Family member login added.';
            }
        } elseif ($action === 'remove') {
            $memberId = (int)($_POST['member_id'] ?? 0);
            if ($memberId <= 0) {
                $err = 'Please select a valid family member.';
            } else {
                $stmt = db()->prepare('DELETE FROM users WHERE id=? AND parent_user_id=? AND role="resident" LIMIT 1');
                $stmt->execute([$memberId, (int)$U['id']]);
                $msg = $stmt->rowCount() ? 'Family member removed.' : 'Family member not found.';
            }
        }
    }
}

$members = [];
if ($isPrimaryResident) {
    $stmt = db()->prepare('SELECT id, owner_name, member_relation, username, created_at FROM users WHERE parent_user_id=? AND role="resident" ORDER BY owner_name');
    $stmt->execute([(int)$U['id']]);
    $members = $stmt->fetchAll();
}

layout_shell_start('Family Members', 'family_members');
?>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
<?php if ($msg): ?><div class="alert ok"><?= e($msg) ?></div><?php endif; ?>

<?php if (!$isPrimaryResident): ?>
  <div class="panel">
    <h3>Family Members</h3>
    <p class="muted">Only a registered primary resident account can add or remove family member logins.</p>
  </div>
<?php else: ?>
  <div class="grid2">
    <div class="panel">
      <h3>Add Family Member</h3>
      <p class="muted small">Create a separate login password for each family member. Their name will appear on the login page under your flat.</p>
      <form method="post" class="form">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="add">
        <label>Family Member Name</label>
        <input type="text" name="member_name" maxlength="150" required>
        <label>Relation (optional)</label>
        <input type="text" name="member_relation" maxlength="60" placeholder="Spouse, Parent, Child, etc.">
        <div class="grid2">
          <div>
            <label>Create Password</label>
            <input type="password" name="password" minlength="6" autocomplete="new-password" required>
          </div>
          <div>
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" minlength="6" autocomplete="new-password" required>
          </div>
        </div>
        <button class="btn primary" type="submit"><i class="fa fa-user-plus"></i> Add Member</button>
      </form>
    </div>

    <div class="panel">
      <h3>Your Family Logins</h3>
      <?php if (!$members): ?>
        <div class="empty"><i class="fa fa-users"></i><div>No family members added yet.</div></div>
      <?php else: ?>
        <table class="tbl">
          <thead><tr><th>Name</th><th>Relation</th><th>Login Flat</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($members as $m): ?>
            <tr>
              <td><b><?= e($m['owner_name']) ?></b><div class="small muted"><?= e($m['username']) ?></div></td>
              <td><?= e($m['member_relation'] ?: '-') ?></td>
              <td><?= e(user_flat_label($U)) ?></td>
              <td>
                <form method="post" onsubmit="return confirm('Remove this family member login?');">
                  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                  <input type="hidden" name="action" value="remove">
                  <input type="hidden" name="member_id" value="<?= (int)$m['id'] ?>">
                  <button class="btn ghost" type="submit"><i class="fa fa-trash"></i> Remove</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
<?php endif; ?>

<?php layout_shell_end(); ?>
